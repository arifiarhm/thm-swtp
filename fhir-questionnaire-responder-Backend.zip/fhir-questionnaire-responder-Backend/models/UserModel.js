
import { Sequelize } from "sequelize";
import db from "../config/database.js";
const { DataTypes } = Sequelize;



// Definition des Benutzermodells für die db tabelle 'users'
const Users = db.define('users', {
    user_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
    name: {
        type: DataTypes.STRING
    },
    email: {
        type: DataTypes.STRING,
        unique: true,
    },
    password: {
        type: DataTypes.STRING
    },
    refresh_token: {
        type: DataTypes.TEXT
    },
    reset_token: {
        type: DataTypes.TEXT
    },
    status: {
        type: DataTypes.ENUM('verified', 'unverified'),
        defaultValue: 'unverified',
    },
},{
    // Festlegen des Tabellennamens in der Datenbank als 'users'
    freezeTableName:true
});

// Exportieren des Benutzermodells für die Verwendung in anderen Dateien
export default Users;
