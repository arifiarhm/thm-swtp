// models/HistoryModel.js

import { Sequelize } from "sequelize";
import db from "../config/database.js";
import Questionnaire from "./QuestionnaireModel.js";
const { DataTypes } = Sequelize;


// Define History model
const History = db.define('histories', {
    // Primary key for the History table
    history_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    // Foreign key referencing the questionnaire associated with this history entry
    questionnaire_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'questionnaires',
        key: 'questionnaire_id',
      },
    },
  
    // JSONB field to store the state before changes
    json_vor: {
      type: DataTypes.JSONB,
      allowNull: false,
    },
    // JSONB field to store the state after changes
    json_nach: {
      type: DataTypes.JSONB,
      allowNull: false,
    },
    // Timestamp indicating when the history record was submitted
    submitted_at: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  });

  History.belongsTo(Questionnaire, {
    foreignKey: 'questionnaire_id',
    onDelete: 'CASCADE',
  });
  
  // Export Model
  export default History;
  
