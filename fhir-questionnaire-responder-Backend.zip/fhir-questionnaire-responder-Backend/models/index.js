'use strict';

// Laden der erforderlichen Module
const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');
const process = require('process');

// Determine the filename of the current file
const basename = path.basename(__filename);

// Set the environment variable (development, production, etc.)
const env = process.env.NODE_ENV || 'development';

// Load the database configuration from the configuration file
const config = require(__dirname + '/../config/config.json')[env];

// Initialize the database object
const db = {};

// Configure the Sequelize instance with database information
let sequelize;
if (config.use_env_variable) {
  // Use environment variables for connecting to the database
  sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
  // Use configuration information for connecting to the database
  sequelize = new Sequelize(config.database, config.username, config.password, config);
}

// Read all files in the current directory except this file
fs
  .readdirSync(__dirname)
  .filter(file => {
    return (
      file.indexOf('.') !== 0 &&
      file !== basename &&
      file.slice(-3) === '.js' &&
      file.indexOf('.test.js') === -1
    );
  })
  .forEach(file => {
    // Load each model and associate it with the Sequelize instance
    const model = require(path.join(__dirname, file))(sequelize, Sequelize.DataTypes);
    db[model.name] = model;
  });

// Iterate through all models and establish associations (if any)
Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

// Add Sequelize instance and Sequelize module to the export object
db.sequelize = sequelize;
db.Sequelize = Sequelize;

// Export the database object for use in other parts of the application
module.exports = db;
