// models/QuestionnaireModel.js

import { Sequelize } from "sequelize";
import db from "../config/database.js";
import Users from "./UserModel.js";
const { DataTypes } = Sequelize;


// Define Questionnaire model
const Questionnaire = db.define('questionnaires', {
  // Primary key for the Questionnaire table
  questionnaire_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  // JSONB field to store the questionnaire data
  questionnaire_data: {
    type: DataTypes.JSONB,
    allowNull: false,
  },
  // It establishes a relationship with the 'user_id' key in the 'users' table
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'user_id',
    }
  },
 
});

Questionnaire.belongsTo(Users, {
  foreignKey: 'user_id',
  onDelete: 'CASCADE',
});

// Export Model
export default Questionnaire;

