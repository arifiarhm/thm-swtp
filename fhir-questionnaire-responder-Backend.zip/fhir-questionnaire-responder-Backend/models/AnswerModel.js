// models/AnswerModel.js

import { Sequelize } from "sequelize";
import db from "../config/database.js";
import Questionnaire from "./QuestionnaireModel.js";
const { DataTypes } = Sequelize;


// Define Answer model
const Answers = db.define('answers', {
  // Primary key for the Answer table
  answer_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  // The actual value of the answer, stored as JSONB
  answer_value: {
    type: DataTypes.JSONB,
    
  },
  //to associate the answer with the specific questionnaire. This will be used for export function
  questionnaire_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'questionnaires',
      key: 'questionnaire_id',
    },
   
  }
});

Answers.belongsTo(Questionnaire, {
  foreignKey: 'questionnaire_id',
  onDelete: 'CASCADE',
});


// Export Model
export default Answers;
