// index.js
import express from "express";
import dotenv from "dotenv";
import cookieParser from "cookie-parser";
import cors from "cors";
import db from "./config/database.js";
import router from "./routes/index.js";
import multer from "multer";
import { importQuestionnaire } from './controllers/Questionnaire.js';
import winston from 'winston';
const app = express();

// Middleware for analyzing JSON and URL parameters
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Configure environment variables from the .env file
dotenv.config();

// Async function to check database connection
const connectToDatabase = async () => {
    try {
        // Check the database connection and log a message to the console
        await db.authenticate();
        logger.info('Database connected..');
    } catch (error) {
        // Handle errors and log to the console if the database connection fails
        console.error('Error connecting to the database:', error);
        process.exit(1); // Exit the process if the database connection fails
    }
};

// Call the async function to connect to the database
connectToDatabase();

// Middleware for CORS
app.use(cors({ credentials: true, origin: 'http://localhost:3000' }));

// Middleware for analyzing cookies
app.use(cookieParser());

// Route handlers
app.use(router);
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
  ],
});

// Test-Lognachricht
logger.info('Logger initialisiert');

// Async function to sync the database
const syncDatabase = async () => {
    try {
        // Sync the database
        await db.sync();
        console.log('Database synchronized..');
    } catch (error) {
        // Handle errors and log to the console if the database synchronization fails
        console.error('Error synchronizing the database:', error);
        process.exit(1); // Exit the process if the database synchronization fails
    }
};

// Call the async function to sync the database
syncDatabase();

// Specify the API path in the router
app.use("/api", router);

// Configure multer for handling file uploads
const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    cb(null, true);
  },
});
app.post('/import', upload.single('jsonFile'), importQuestionnaire);

// Start the server and listen on port 5001
app.listen(5001, () => console.log('Server running at port 5001'));
