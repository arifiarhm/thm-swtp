//controllers/Users.js

import Users from "../models/UserModel.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { sendVerificationEmail } from "../utils/util.js"
import { sendPasswordChangeEmail } from "../utils/util.js";
import { sendForgetPasswordEmail } from "../utils/util.js";
import History from "../models/HistoryModel.js";
import Questionnaire from "../models/QuestionnaireModel.js";
import validator from "validator";
import Answers from "../models/AnswerModel.js";

// Get user data
export const getUsers = async(req,res) => {
    try {
        // Retrieve user data from the database including user_id, name, and email
        const users = await Users.findAll({
            attributes: ['user_id', 'name', 'email']
        });
        // Respond with the retrieved user data
        res.json(users);
    } catch (error) {
        console.log(error);
        // Handle any errors that occur during the process
    } 
}

// Register a new user
export const Register = async(req,res) => {
    const { name, email, password, confPassword} = req.body;

    const lowerCaseEmail = email.toLowerCase();
    // Validate email format using validator
    if (!validator.isEmail(lowerCaseEmail)) {
        return res.status(400).json({msg: "Invalid e-mail format"});
    }

    // Validate password format
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.;,-_+'])[A-Za-z\d@$!%*?&.;,-_+']{8,}$/;
    if (!passwordRegex.test(password)) {
        return res.status(400).json({msg: "Invalid password. Your password must be at least 8 characters long, contain at least one capital letter, and at least one special character."});
    }
    if(password !== confPassword) return res.status(400).json({msg: "Password doesn't match"});

    // Encrypt the password
    const salt = await bcrypt.genSalt();
    const hashPassword = await bcrypt.hash(password, salt);

    // Create a verification token
    const verificationToken = jwt.sign({ email: lowerCaseEmail }, process.env.VERIFICATION_TOKEN_SECRET, {
        expiresIn: '1d'
    });

    try {
        // Save user data in the database
        await Users.create({
            name: name,
            email: lowerCaseEmail,
            password: hashPassword,
            verification_token: verificationToken,
            status: 'unverified', 
        });

        // Send an email for email verification to the user
        sendVerificationEmail(lowerCaseEmail, verificationToken);

        // Respond to the request
        res.json({msg: "Registration successful, please check your E-mail."});
    } catch (error) {
        console.log(error);
        // Handle registration failure due to existing email
        res.status(500).json({msg: "E-mail already registered. Please use a different E-mail"});
    }
}

// Log in a user
export const Login = async (req, res) => {
    try {

        //change to lower case
        const lowerCaseEmail = req.body.email.toLowerCase();
        // Find the user by email
        const user = await Users.findOne({
            where: {
                email: lowerCaseEmail
            }
        });

        // If the user is not found, respond with an error
        if (!user) {
            return res.status(404).json({ error: "E-Mail not found" });
        }

        // Check if the provided password matches the stored password
        const match = await bcrypt.compare(req.body.password, user.password);

        // If the password doesn't match, respond with an error
        if (!match) {
            return res.status(400).json({ error: "Password doesn't match" });
        }

        // Create an access token and a refresh token
        const userId = user.user_id;
        const name = user.name;
        const email = user.email;
        
        const accessToken = jwt.sign({ userId, name, email }, process.env.ACCESS_TOKEN_SECRET, {
            expiresIn: '1d'
        });
        const refreshToken = jwt.sign({ userId, name, email }, process.env.REFRESH_TOKEN_SECRET, {
            expiresIn: '1d'
        });

        // Update the refresh token in the database
        await Users.update({ refresh_token: refreshToken }, {
            where: {
                user_id: userId
            }
        });

        // Set the refresh token as a cookie
        res.cookie('refreshToken', refreshToken, {
            httpOnly: true,
            maxAge: 24 * 60 * 60 * 1000,
        });

        // Respond with the access token
        res.json({ accessToken });

    } catch (error) {
        // Handle general login errors
        console.error(error);
        res.status(500).json({ error: "Error during login" });
    }
}

// Log out a user
export const Logout = async(req, res) => {
    const refreshToken = req.cookies.refreshToken;
    if(!refreshToken) return res.sendStatus(204);

    // Find the user based on the refresh token
    const user = await Users.findOne({
        where: {
            refresh_token: refreshToken
        }
    });

    if (!user || !user.refresh_token) {
        console.log('User not found or update token missing');
        return res.sendStatus(403).json({ error: 'Forbidden - User not found or update token missing' });
    }

    // Update the refresh token to null
    const updatedUser = await Users.update(
        { refresh_token: null },
        { where: { user_id: user.user_id }, returning: true }
    );
    if (!updatedUser || updatedUser[0] !== 1) {
        console.log('Refresh-Token could not be updated ');
        return res.sendStatus(500).json({ error: 'Internal Server Error - Refresh-Token could not be updated' });
    }

    // Clear the refresh token cookie
    res.clearCookie('refreshToken');
    return res.status(200).json({ message: 'User successfully logged out' });
}

// Change user password
export const changePassword = async (req, res) => {
    const { oldPassword, newPassword, confirmNewPassword } = req.body;
  
    // Log user information from the token
    console.log('User ID from token:', req.user.userId); 
    console.log('User object from token:', req.user); 
    console.log('Old Password:', oldPassword); 

    // Validate the new password
    if(newPassword !== confirmNewPassword) return res.status(400).json({msg: "Invalid password"});
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.;,-_+'])[A-Za-z\d@$!%*?&.;,-_+']{8,}$/;
    if (!passwordRegex.test(newPassword)) {
        return res.status(400).json({msg: "Invalid password. Your password must be at least 8 characters long, contain at least one capital letter and at least one special character."});
    }
  
    try {
      // Retrieve user data from the token
      const user = await Users.findByPk(req.user.userId);
      console.log('User:', user);

      if (!user) {
        console.error("User not found:", req.user.userId);
        return res.status(404).json({ error: "User not found" });
    }
  
      // Check if the old password matches
      const match = await bcrypt.compare(oldPassword, user.password);
      if (!match) {
        return res.status(400).json({ error: "Your old password is incorrect" });
      }
  
      // Encrypt and save the new password in the database
      const salt = await bcrypt.genSalt();
      const hashedPassword = await bcrypt.hash(newPassword, salt);
      await Users.update({ password: hashedPassword }, { where: { user_id: req.user.userId } });
      console.log('Hashed Password:', hashedPassword);

      // Send an email to confirm the password change
      sendPasswordChangeEmail(user.email);
  
      // Respond to the request
      res.json({ message: "Password changed successfully" });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Password change failed" });
    }
  };

// Forget password functionality
export const forgetPassword = async (req, res) => {
    const { email } = req.body;

    //change to lower case
    const lowerCaseEmail = email.toLowerCase();
    // Check if the user's email exists in the database
    const user = await Users.findOne({
        where: {
            email: lowerCaseEmail,
        },
    });

    // If the user is not found, respond with an error
    if (!user) {
        return res.status(404).json({ error: 'E-Mail not found' });
    }

    try {
        // Create a reset token for password
        const resetToken = jwt.sign({ lowerCaseEmail }, process.env.RESET_TOKEN_SECRET, {
            expiresIn: '1h',
        });

        // Save the reset token in the database
        await Users.update({ reset_token: resetToken }, { where: { email: lowerCaseEmail } });

        // Send an email with a link to reset the password (if needed)
        sendForgetPasswordEmail(lowerCaseEmail, resetToken);
        

        // Respond with the reset token
        res.json({ resetToken });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

// Reset password after forgetting it
export const resetPassword = async (req, res) => {
    const { resetToken, newPassword, confirmNewPassword } = req.body;

    try {
        // Verify the reset token
        const decoded = jwt.verify(resetToken, process.env.RESET_TOKEN_SECRET);

        // Extract email from the token
        //change to lower case
        const email = decoded.email.toLowerCase();

        // Check if the new password matches the confirm password
        if (newPassword !== confirmNewPassword) {
            return res.status(400).json({ error: "Password doesn't match" });
        }

        // Validate the new password
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.;,-_+'])[A-Za-z\d@$!%*?&.;,-_+']{8,}$/;
        if (!passwordRegex.test(newPassword)) {
            return res.status(400).json({msg: "Invalid password. Your password must be at least 8 characters long, contain at least one capital letter and at least one special character."});
        }

        // Hash the new password
        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(newPassword, salt);

        // Update the password in the database and clear the reset token
        await Users.update({ password: hashedPassword, reset_token: null }, { where: { email } });

        // Respond to the request
        res.json({ message: "Password changed successfully" });

        // Send an email to confirm the password change
         sendPasswordChangeEmail(email);
        
        // Additional email confirmation or success message (if needed)
    } catch (error) {
        console.error(error);
        res.status(403).json({ error: "Invalid or expired reset token" });
    }
};


// Delete user account
export const deleteUserAccount = async (req, res) => {
    try {
        const userId = req.user.userId;
        
        const { password, confPassword } = req.body;

        // Validate password
        if (password !== confPassword) {
            return res.status(400).json({ error: 'Password confirmation does not match' });
        }

        // Retrieve user data from the database
        const user = await Users.findByPk(userId);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Compare the password from the client request with the password in the database
        const match = await bcrypt.compare(password, user.password);

        if (!match) {
            return res.status(400).json({ error: "Password doesn't match" });
        }
       
        // Find all questionnaire IDs associated with the user
        const questionnaires = await Questionnaire.findAll({
            where: { user_id: userId },
            attributes: ['questionnaire_id'],
            raw: true,
        });

        // Extract questionnaire IDs from the array of objects
        const qid = questionnaires.map(q => q.questionnaire_id);

        
        // Delete related records first
        await History.destroy({
            where: { questionnaire_id: qid }
        });
        await Answers.destroy({
            where: { questionnaire_id: qid }
        });
        await Questionnaire.destroy({
            where: { user_id: userId }
        });

        // Now, delete the user and associated questionnaire
        await Users.destroy({
            where: { user_id: userId }
        });

       

        res.json({ message: 'User account and associated data successfully deleted' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to delete user account' });
    }
};
