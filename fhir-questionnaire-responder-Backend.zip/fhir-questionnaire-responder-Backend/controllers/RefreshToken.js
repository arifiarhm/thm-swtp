import Users from "../models/UserModel.js";
import jwt from "jsonwebtoken";

// Refresh the access token using the provided refresh token stored in the user's cookies
export const refreshToken = async (req, res) => {
    // Extract the refresh token from the request cookies
    const { refreshToken } = req.cookies;

    // Check if the refresh token is missing
    if (!refreshToken) {
        // Send a Forbidden status and an error message if the refresh token is missing
        return res.sendStatus(403).json({ error: 'Forbidden - Refresh token missing' });
    }

    try {
        // Verify the integrity of the refresh token using the secret
        const decoded = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET);

        // Find the user based on the user ID obtained from the decoded token
        const user = await Users.findOne({
            where: {
                id: decoded.userId,
            },
        });

        // Check if the user is found and has a refresh token
        if (!user || !user.refresh_token) {
            console.log('User not found or refresh token missing');
            // Send a Forbidden status and an error message if the user is not found or the refresh token is missing
            return res.sendStatus(403).json({ error: 'Forbidden - User not found or refresh token missing' });
        }

        // Create a new access token with a limited expiration time
        const newAccessToken = jwt.sign({ userId: user.id, email: user.email }, process.env.ACCESS_TOKEN_SECRET, {
            expiresIn: '15m',
        });

        // Send the response with the new access token
        res.json({ accessToken: newAccessToken });
    } catch (error) {
        // Log and send a Forbidden status with an error message if an error occurs during the token refresh
        console.error('Error refreshing token:', error);
        return res.sendStatus(403).json({ error: 'Forbidden' });
    }
};
