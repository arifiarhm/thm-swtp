// controllers/Questionnaire.js

// Import necessary models and modules
import Questionnaire from '../models/QuestionnaireModel.js';
import Answers from '../models/AnswerModel.js';
import History from '../models/HistoryModel.js';
import Users from '../models/UserModel.js';
import multer from 'multer';

// Import validation and authentication middleware
import { validateAnswer, validateRequiredQuestions } from '../middleware/Validations.js';
import { authentication } from '../middleware/Authentication.js';

// Configure multer for handling file uploads
const storage = multer.memoryStorage();
const upload = multer({ storage: storage }).single('file');

// Retrieve full details of a questionnaire by ID
export const getQuestionnaireById = async (req, res) => {
  const questionnaireId = req.params.qid;

  try {
    // Attempt to find the questionnaire by its ID using the Sequelize findByPk method.
    const foundQuestionnaire = await Questionnaire.findByPk(questionnaireId);

    if (!foundQuestionnaire) {
      return res.status(404).json({
        success: false,
        error: "Questionnaire not found",
      });
    }

    res.status(200).json({
      success: true,
      data: foundQuestionnaire,
    });
  } catch (error) {
    console.error("Error retrieving questionnaire:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error",
    });
  }
};

// Provide a representation of the questionnaire's data
export const getDataRepresentation = async (req, res) => {
  const questionnaireId = req.params.qid;

  try {
    // Retrieve and parse questionnaire data
    const questionnaire_data = (await Questionnaire.findByPk(questionnaireId)).questionnaire_data;
    const parsedjson = JSON.parse(questionnaire_data);

    if (!questionnaire_data) {
      return res.status(404).json({
        success: false,
        error: "Questionnaire not found",
      });
    }

    const { title, description, item } = parsedjson;

    // Process the data representation based on different question types
    const processedData = item.map((question) => {
      const { linkId, text, type, answerOption, item: subItems } = question;

      switch (type) {
        case "choice":
          // Process choice questions
          return {
            linkId,
            text,
            type,
            options: answerOption.map((option) => option.valueCoding.display),
          };

        case "boolean":
          // Process boolean questions
          return {
            linkId,
            text,
            type,
          };

        case "integer":
          // Process integer questions
          return {
            linkId,
            text,
            type,
          };

        case "string":
          // Process string questions
          return {
            linkId,
            text,
            type,
          };

        case "open-choice":
          // Process open-choice questions
          return {
            linkId,
            text,
            type,
          };

        default:
          // Handle unsupported question types
          return {
            linkId,
            text,
            type: "unsupported",
          };
      }
    });

    res.status(200).json({
      success: true,
      data: processedData,
    });
  } catch (error) {
    console.error("Error retrieving data representation:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error",
    });
  }
};

// Enable submission of answers according to the type of questions, including creating records in the answer model
export const submitAnswers = async (req, res) => {
  const questionnaireId = req.params.qid;
  const answers = req.body;

  try {
    // Retrieve user data from the token
    const user = await Users.findByPk(req.user.userId);

    if (!user) {
      console.error("User not found:", req.user.userId);
      return res.status(404).json({
        error: "User not found",
      });
    }

    // Check if the user is allowed to answer the questionnaire
    const existingQuestionnaire = await Questionnaire.findByPk(questionnaireId);
    if (!existingQuestionnaire || existingQuestionnaire.user_id !== user.user_id) {
      return res.status(404).json({
        error: "You are not allowed to answer this Questionnaire",
      });
    }

    const { item } = JSON.parse(existingQuestionnaire.questionnaire_data);

    // Validate required questions
    const requiredValidationResult = validateRequiredQuestions(item, answers);
    if (requiredValidationResult) {
      return res.status(400).json({
        success: false,
        error: requiredValidationResult,
      });
    }

    // Validate and save answers
    for (const answer of answers) {
      const { questionId, answerValue } = answer;
      const question = item.find((q) => q.linkId === questionId);

      const validationError = validateAnswer(question, answerValue);
      if (validationError) {
        return res.status(400).json({
          success: false,
          error: validationError,
        });
      }
    }

    // Create a new answer record
    const createdAnswer = await Answers.create({
      questionnaire_id: questionnaireId,
      answer_value: answers,
    });

    // Save history entry if the answer has changed
    await History.create({
      questionnaire_id: questionnaireId,
      json_vor: {},
      json_nach: {
        answer_id: createdAnswer.answer_id,
        answer_value: answers,
      },
    });

    res.status(201).json({
      success: true,
      message: "Answers submitted successfully",
    });
  } catch (error) {
    console.error("Error submitting answers:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error",
    });
  }
};

// Export all answers of a specific questionnaire
export const getAnswerByQuestionnaireid = async (req, res) => {
  const questionnaireId = req.params.qid;

  try {
    // Retrieve answers for the questionnaire in descending order to get the most recent entry
    const foundAnswers = await Answers.findAll({
      where: {
        questionnaire_id: questionnaireId,
      },
      order: [["updatedAt", "DESC"]],
    });

    if (!foundAnswers) {
      return res.status(404).json({
        success: false,
        error: "Answers not found for the questionnaire",
      });
    }

    res.status(200).json({
      success: true,
      data: foundAnswers,
    });
  } catch (error) {
    console.error("Error retrieving answers:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error",
    });
  }
};

// Export (download) the questions and their associated answers to the user's hardware in a JSON file
export const downloadQuestionnaire = async (req, res) => {
  const questionnaireId = req.params.qid;

  try {
    // Retrieve questionnaire data
    const { questionnaire_data } = await Questionnaire.findByPk(questionnaireId);
    const parsedjson = JSON.parse(questionnaire_data);

    if (!parsedjson) {
      return res.status(404).json({
        success: false,
        error: "Questionnaire not found",
      });
    }

    // Retrieve all answers associated with the questionnaire, ordered by their update timestamp in descending order
    const foundAnswers = await Answers.findAll({
      where: {
        questionnaire_id: questionnaireId,
      },
      order: [["updatedAt", "DESC"]],
    });

    // Create a result object containing the parsed questionnaire and the answers in JSON format
    const questionnaireResult = {
      questionnaire: parsedjson,
      answers: foundAnswers.map((answer) => answer.toJSON()),
    };

    return res.status(200).json(questionnaireResult);
  } catch (error) {
    console.error("Error downloading questionnaire:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error",
    });
  }
};

// Handle importing a questionnaire
export const importQuestionnaire = (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      console.error('Error uploading file:', err);
      return res.status(500).json({
        success: false,
        error: 'Error uploading file',
      });
    }

    try {
      // Retrieve user data from the token
      const user = await Users.findByPk(req.user.userId);

      if (!user) {
        console.error('User not found:', req.user.userId);
        return res.status(404).json({
          error: 'User not found',
        });
      }

      // Parse the uploaded JSON file
      const jsonData = JSON.parse(req.file.buffer.toString());
      console.log('Raw JSON Data:', jsonData);

      if (!jsonData) {
        return res.status(400).json({
          success: false,
          error: 'Invalid or missing data in the file',
        });
      }

      // Save the imported questionnaire and create a history entry
      const savedQuestionnaire = await Questionnaire.create({
        questionnaire_data: JSON.stringify(jsonData),
        user_id: req.user.userId,
      });

      await History.create({
        questionnaire_id: savedQuestionnaire.questionnaire_id,
        last_answered: null,
        total_questions: 1,
        json_vor: {},
        json_nach: jsonData,
        answered_questions: 0,
      });

      res.status(200).json({
        success: true,
        data: savedQuestionnaire,
      });
    } catch (error) {
      console.error('Error importing questionnaire:', error);
      res.status(500).json({
        success: false,
        error: 'Internal server error',
      });
    }
  });
};

// Handle deleting an imported questionnaire including answers and history
export const deleteQuestionnaire = async (req, res) => {
  const questionnaireId = req.params.qid;

  try {
    // Check if the user is allowed to delete the questionnaire
    const isAuth = await authentication(req.user.userId, Questionnaire, questionnaireId);
    if (!isAuth) {
      return res.status(401).json({
        success: false,
        error: "You are not allowed to delete this Questionnaire",
      });
    }

    // Retrieve answers associated with the questionnaire
    const foundAnswers = await Answers.findAll({
      where: {
        questionnaire_id: questionnaireId,
      },
    });

    // Delete the associated history entries
    await History.destroy({
      where: {
        questionnaire_id: questionnaireId,
      },
    });

    // Delete the associated answers
    const answerDeleted = await Answers.destroy({
      where: {
        questionnaire_id: questionnaireId,
      },
    });

    // Delete the questionnaire
    const questionnaireDeleted = await Questionnaire.destroy({
      where: {
        questionnaire_id: questionnaireId,
      },
      returning: true, // Enable returning the deleted values
    });

    res.status(200).json({
      success: true,
      message: "Questionnaire deleted successfully",
      data: { questionnaire: questionnaireDeleted, answer: answerDeleted },
    });
  } catch (error) {
    console.error("Error deleting questionnaire:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error",
    });
  }
};

// Enable editing of answers
export const editAnswers = async (req, res) => {
  const questionnaireId = req.params.qid;
  const answers = req.body;
  const answerId = req.params.aid;

  try {
    // Retrieve user data from the token
    const user = await Users.findByPk(req.user.userId);

    if (!user) {
      console.error("User not found:", req.user.userId);
      return res.status(404).json({
        error: "User not found",
      });
    }

    // Check if the user is allowed to edit the answer
    const existingQuestionnaire = await Questionnaire.findByPk(questionnaireId);
    const isAuth = await authentication(req.user.userId, Questionnaire, questionnaireId);
    if (!existingQuestionnaire || !isAuth) {
      return res.status(401).json({
        error: "You are not allowed to edit this Answer",
      });
    }

    const { item } = JSON.parse(existingQuestionnaire.questionnaire_data);

    // Validate required questions
    const requiredValidationResult = validateRequiredQuestions(item, answers);
    if (requiredValidationResult) {
      return res.status(400).json({
        success: false,
        error: requiredValidationResult,
      });
    }

    for (const answer of answers) {
      const { questionId, answerValue } = answer;
      const question = item.find((q) => q.linkId === questionId);

      // Validate and update answers
      const validationError = validateAnswer(question, answerValue);
      if (validationError) {
        return res.status(400).json({
          success: false,
          error: validationError,
        });
      }
    }

    // Retrieve the existing answer for comparison
    const existingAnswer = await Answers.findOne({
      where: {
        answer_id: answerId,
        questionnaire_id: questionnaireId,
      },
    });

    if (existingAnswer) {
      // Update the answer
      await Answers.update(
        {
          answer_value: answers,
        },
        {
          where: {
            answer_id: answerId,
            questionnaire_id: questionnaireId,
          },
        }
      );

      // Save history entry if the answer has changed
      await History.create({
        answer_id: answerId,
        questionnaire_id: questionnaireId,
        json_vor: {
          answer_id: answerId,
          answer_value: existingAnswer.answer_value,
        },
        json_nach: {
          answer_id: answerId,
          answer_value: answers,
        },
      });
    }

    res.status(200).json({
      success: true,
      message: "Answers updated successfully",
    });
  } catch (error) {
    console.error("Error updating answers:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error",
    });
  }
};

// Delete answers including updating status history
export const deleteAnswer = async (req, res) => {
  const answerId = req.params.aid;
  const questionnaireId = req.params.qid;

  try {
    // Retrieve user data from the token
    const user = await Users.findByPk(req.user.userId);

    if (!user) {
      console.error("User not found:", req.user.userId);
      return res.status(404).json({
        error: "User not found",
      });
    }

    // Check if the user is allowed to delete the answer
    const existingQuestionnaire = await Questionnaire.findByPk(questionnaireId);
    if (!existingQuestionnaire || existingQuestionnaire.user_id !== user.user_id) {
      return res.status(404).json({
        error: "You are not allowed to delete this Answer",
      });
    }

    // Find the answer to delete
    const answerToDelete = await Answers.findOne({
      where: {
        answer_id: answerId,
      },
    });

    if (!answerToDelete) {
      return res.status(404).json({
        success: false,
        error: "Answer not found",
      });
    }

    // Delete the answer based on answer_id
    const rowsDeleted = await Answers.destroy({
      where: {
        answer_id: answerId,
      },
      returning: true, // Enable returning the deleted values
    });

    // Update history
    await History.create({
      answer_id: answerId,
      questionnaire_id: questionnaireId,
      json_vor: {
        answer_id: answerId,
        answer_value: answerToDelete.answer_value,
      },
      json_nach: {},
    });

    res.status(200).json({
      success: true,
      message: "Delete successful",
    });
  } catch (error) {
    console.error("Error deleting answer:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error",
    });
  }
};

// Get all questionnaires for a specific user
export const getAllQuestionnairesForUser = async (req, res) => {
  
  try {
    const user = await Users.findByPk(req.user.userId);
    console.log("User:", user);

    if (!user) {
      console.error("User not found:", req.user.userId);
      return res.status(404).json({
        error: "User not found",
      });
    }

    // Alle Fragebögen für den Benutzer abrufen
    const userQuestionnaires = await Questionnaire.findAll({
      where: {
        user_id: user.user_id,
      },
    });

    // Logge die SQL-Abfrage
    console.log('SQL-Abfrage:', userQuestionnaires.toString());

    res.status(200).json({
      success: true,
      data: userQuestionnaires,
    });
  } catch (error) {
    console.error("Error retrieving user questionnaires:", error);
    res.status(500).json({
      success: false,
      error: "Internal server error",
    });
  }
};
