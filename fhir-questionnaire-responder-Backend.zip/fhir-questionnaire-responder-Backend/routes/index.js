//routes/index.js
/*this file defines the routing logic for the Express.js application. 
In an Express.js application, routes are used to define how the application 
responds to client requests based on the request method and URL. This file specifically*/

import express from "express";
import jwt from "jsonwebtoken";
import { getUsers, Register, Login, Logout } from "../controllers/Users.js";
import { changePassword } from '../controllers/Users.js';
import { forgetPassword, resetPassword } from "../controllers/Users.js";
import { deleteUserAccount } from '../controllers/Users.js';
import { verifyToken } from "../middleware/VerifyToken.js";
import { refreshToken } from "../controllers/RefreshToken.js";
import Users from "../models/UserModel.js";


import { getQuestionnaireById, 
    importQuestionnaire, 
    deleteAnswer, 
    getAnswerByQuestionnaireid, 
    downloadQuestionnaire,
    getDataRepresentation,
    submitAnswers,editAnswers, deleteQuestionnaire } from '../controllers/Questionnaire.js';




const router = express.Router();

// Endpunkte und zugehörige Controller-Funktionen definieren

router.get('/users', verifyToken, getUsers);
router.post('/users', Register);
router.post('/login', Login);
router.get('/token', refreshToken);

router.delete('/logout', Logout);
router.get('/verify/:token', async (req, res) => {
    // Extrahieren des Verifizierungstokens aus den Routenparametern
    const verificationToken = req.params.token;
    
    try {
        // Verifiziere das Token und erhalte die dekodierte Information
        const decoded = jwt.verify(verificationToken, process.env.VERIFICATION_TOKEN_SECRET);
        // Extrahiere die E-Mail-Adresse aus der dekodierten Information
        const userEmail = decoded.email;

        // Markiere das Benutzerkonto als verifiziert in der db
        await Users.update({ verified: true, status: 'verified' }, { where: { email: userEmail } });

        // redirect zur Login-Seite oder Erfolgsseite nach erfolgreicher Verifizierung
        res.redirect('http://localhost:3000/login'); //anhand port, die frontend läuft
    } catch (error) {
        // Behandlung von Fehlern bei ungültigem Verifizierungstoken
        console.error(error);
        res.status(400).send('Ungültiges Verifizierungstoken');
    }

});

router.post('/change-password', verifyToken, changePassword);
router.post('/forget-password', forgetPassword);
router.post('/reset-password', resetPassword);
router.delete('/users/delete-account', verifyToken, deleteUserAccount);

router.get('/reset/:token', async (req, res) => {
    // Extrahieren des ResetTokens aus den Routenparametern
    const resetToken = req.params.token;
    
    try {
        // Verifiziere das Token und erhalte die dekodierte Information
        const decoded = jwt.verify(resetToken, process.env.RESET_TOKEN_SECRET);
        // Extrahiere die E-Mail-Adresse aus der dekodierten Information
        const userEmail = decoded.email;

        // redirect zur reset passwort-Seite 
        res.redirect('http://localhost:3000/reset-password'); //anhand port, die frontend läuft
    } catch (error) {
        // Behandlung von Fehlern bei ungültigem Verifizierungstoken
        console.error(error);
        res.status(400).send('Ungültiges Resettoken');
    }

});



//  endpoint '/protected', die eine Authentifizierung erfordern
router.get('/protected', verifyToken, (req, res) => {
    const userEmail = req.user.email;
    res.json({ message: 'Erfolgreicher Zugriff auf den geschützten Endpunkt', userEmail });
});



// Handling GET request to get questionnaire by id
router.get('/:qid', getQuestionnaireById);

// Handling POST request to import questionnaire
router.post('/import',verifyToken, importQuestionnaire);


//Handling deleting Questionnaire
router.delete('/delete/:qid',verifyToken, deleteQuestionnaire);


// Handling DELETE request to delete answer
router.delete('/delete/:qid/:aid',verifyToken, deleteAnswer);

//Handling GET request to show answers of questionnaire
router.get('/get-answers-by-questionnaire/:qid', getAnswerByQuestionnaireid);

//Handling GET request to enable users to download questionnaire and its answers
router.get('/download-questionnaire/:qid', downloadQuestionnaire);

//Handling GET request to show data representation of questionnaire
router.get('/api/questionnaires/:qid/data-representation', getDataRepresentation);

//Handling POST request to enable submit answers
//with token, in autorization the bearer token must be validated
//router.post('/api/questionnaires/:id/submit-answers',verifyToken, submitAnswers);

router.post('/api/questionnaires/:qid/submit-answers',verifyToken,submitAnswers);

//Handling PUT request to enable edit answers
router.put('/api/questionnaires/:qid/answers/edit/:aid',verifyToken, editAnswers);





// Exportiere den Router für die Verwendung in anderen Dateien
export default router;
