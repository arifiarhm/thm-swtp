import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

// Erstellen eines Nodemailer-Transporters mit Gmail-Dienst
const transporter = nodemailer.createTransport({
    service: 'gmail',
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
    }
});

// Funktion zum Senden einer Verifizierungs-E-Mail
export const sendVerificationEmail = (email, verificationToken) => {
    // Konfiguration für die E-Mail
    const mailOptions = {
        // Absenderadresse
        from: {
            name: 'Info_FHIR',
            address: process.env.EMAIL_USER
        },
        to: email, // Empfängeradresse (Benutzer-E-Mail für Verifizierung)
        subject: 'New account verification', // Betreff der E-Mail
        text: `Click on the link to verify your E-mail: http://localhost:5001/verify/${verificationToken}` // Text der E-Mail mit Verifizierungslink
    };

    // Senden der E-Mail über den Transporter
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response); // Konsolenausgabe bei erfolgreicher E-Mail-Zustellung
        }
    });
};


//password change
export const sendPasswordChangeEmail = (email) => {
    const mailOptions = {
        from: {
            name: 'Info_FHIR',
            address: process.env.EMAIL_USER
        },
        to: email,
        subject: 'Confirmation of the new password ',
        text: 'Your password has been successfully changed.'
    };

    // Senden der E-Mail über den Transporter
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
};


//forget password
// Funktion zum Senden einer E-Mail für das Zurücksetzen des Passworts
export const sendForgetPasswordEmail = (email, resetToken) => {
    const mailOptions = {
        from: {
            name: 'Info_FHIR',
            address: process.env.EMAIL_USER,
        },
        to: email,
        subject: 'Reset password', // Betreff der E-Mail
        text: `Click on the link to reset your password: http://localhost:5001/reset/${resetToken}`, // Text der E-Mail mit Link zum Zurücksetzen des Passworts
    };

    // Senden der E-Mail über den Transporter
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
};
