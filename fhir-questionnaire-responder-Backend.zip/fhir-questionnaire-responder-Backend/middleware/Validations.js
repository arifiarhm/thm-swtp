//please npm install moment
//moment package  is for type date, time, dateTime

import moment from "moment";

// This function validates an answer for a given question based on its type and value.
export const validateAnswer = (question, answerValue) => {

  switch (question.type) {
    // validation logic for 'open-choice' and 'choice' 
    case 'open-choice':
    case 'choice':
      if (!question.answerOption.some(opt => opt.valueCoding.display === answerValue)) {
        return `Invalid answer for question ${question.text}: ${answerValue}`;
      }
      break;

    //  validation logic for 'string'  
    case 'string':
      if (typeof answerValue !== 'string') {
        return `Invalid answer type for question ${question.text}: ${typeof answerValue}`;
      }
      break;
      
    case 'integer':
    // Validation logic for'decimal' question types.  
    case 'decimal':
      if (typeof answerValue !== 'number' || isNaN(answerValue)) {
        return `Invalid answer type for question ${question.text}: ${typeof answerValue}`;
      }
      break;
    // Validation logic for 'group' question types.  
    case 'group':
      
      if (!Array.isArray(answerValue)) {
        return `Invalid answer type for group question ${question.text}: ${typeof answerValue}`;
      }

      for (const groupAnswer of answerValue) {
        if (!groupAnswer.questionId || !groupAnswer.answerValue) {
          return `Invalid answer structure for group question ${question.text}`;
        }

        const subQuestion = question.item.find(subQ => subQ.linkId === groupAnswer.questionId);

        if (!subQuestion) {
          return `Invalid sub-question ${groupAnswer.questionId} for group question ${question.text}`;
        }

        const subQuestionValidation = validateAnswer(subQuestion, groupAnswer.answerValue);
        if (subQuestionValidation) {
          return subQuestionValidation;
        }
      }
      break;
      // Validation logic for 'date', 'time', and 'dateTime' question types.
      case 'date':
          const dateMoment = moment(answerValue, 'YYYY-MM-DD', true);
          if (!dateMoment.isValid()) {
            return `Invalid answer format for question ${question.text}: ${answerValue}`;
          }
          break;
    
        case 'time':
          // Adjust the format based on your specific requirements for time
          const timeMoment = moment(answerValue, 'HH:mm:ss', true);
          if (!timeMoment.isValid()) {
            return `Invalid answer format for question ${question.text}: ${answerValue}`;
          }
          break;
    
        case 'dateTime':
          // Adjust the format based on your specific requirements for dateTime
          const dateTimeMoment = moment(answerValue, 'YYYY-MM-DDTHH:mm:ss', true);
          if (!dateTimeMoment.isValid()) {
            return `Invalid answer format for question ${question.text}: ${answerValue}`;
          }
          break;

    default:
      // Handle other question types if needed
      break;
  }

  return null; // No validation error
}

// This function validates whether required questions have been answered.
export const validateRequiredQuestions = (questions, answers) => {

  // Helper function to find an answer in an array of answers with nested structure.
  const findAnswerWithArray = (question) => {
      return answers
          .filter(a => Array.isArray(a.answerValue))
          .flatMap(a => a.answerValue)
          .find(a => a.questionId === question.linkId);
  };
  // Helper function to find a direct answer for a question.
  const findAnswer = (question) => {
      return answers.find(a => a.questionId === question.linkId);
  };
  // Recursive function to validate a question and its nested questions.
  const validateQuestion = (question, isNested = false) => {
      if (question.required === true) {
          const answer = isNested ? findAnswerWithArray(question) : findAnswer(question);

          if (!answer || !answer.answerValue) {
              return `Answer for question with ID ${question.linkId} is required`;
          }
      }
      // If the question has nested questions, recursively validate each nested question.
      if (question.item && question.item.length > 0) {
          for (const nestedQuestion of question.item) {
              const nestedResult = validateQuestion(nestedQuestion, true);
              if (nestedResult) {
                  return nestedResult;
              }
          }
      }

      return null;
  };

   // Loop through the main questions and validate each one.
  for (const mainQuestion of questions) {
      const validationResult = validateQuestion(mainQuestion);
      if (validationResult) {
          return validationResult;
      }
  }

  return null; // All required questions have answers
};
