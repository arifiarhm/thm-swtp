//To check the authentication



export const authentication = async (userId,model,modelId) => {
   

    const existingModel = await model.findByPk(modelId);
    if(existingModel.user_id !== userId ){
      return false;
    } 
    return true;
}
