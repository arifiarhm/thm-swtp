import jwt from "jsonwebtoken";

// Middleware function to verify access tokens
export const verifyToken = (req, res, next) => {
    // Get the token from the Authorization header
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    // If the token is not present, return a 401 Unauthorized status to the user
    if (!token) {
        return res.status(401).json({ error: "Unauthorized - Token not present" });
    }

    // Use JWT to verify the token with the secret key used during token signing
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, decoded) => {
        if (err) {
            console.error(err);
            // If token verification fails, return a 403 Forbidden status
            return res.status(403).json({ error: 'Forbidden - Token verification failed' });
        }

        // Check if the 'userId' property exists in the decoded object
        if (!decoded.userId) {
            // If 'userId' is missing, return a 403 Forbidden status
            return res.status(403).json({ error: 'Forbidden - Token verification failed' });
        }

        // On success, attach the 'userId', 'name', and 'email' attributes to req.user for use throughout the application
        req.user = {
            userId: decoded.userId,
            name: decoded.name, 
            email: decoded.email
        };
        // Continue to the next middleware or route handler
        next();
    });
};
