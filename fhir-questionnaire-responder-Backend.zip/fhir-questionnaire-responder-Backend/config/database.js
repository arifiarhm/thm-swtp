
//config/database.js

/*This file is typically used to configure and initialize an instance of Sequelize, 
which is an Object-Relational Mapping (ORM) library for Node.js. 
Sequelize facilitates interaction with relational databases, and in this case, 
is configured to work with PostgreSQL.*/

//import sequelize class from library 'sequelize'
import {Sequelize} from "sequelize"; 
const db = new Sequelize ('swtp','postgres','merdeka1945', {
    host: "localhost",
    dialect: "postgres"
});
// Exportiere die konfigurierte Sequelize-Instanz als Standardexport dieses Moduls
export default db;


