<template>
  <!-- The main application container -->
  <div id="app">
    <!-- Main content area, controlled by Vue Router -->
    <router-view />
  </div>
</template>

<script>
export default {
  // Component name for Vue Devtools and internal reference
  name: 'App',
};
</script>

<style>
/* Styling for the body of the application */
body {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  margin: 0;
  padding: 0;
}

/* Styling for the main application container */
#app {
  text-align: center;
  color: #2c3e50;
  margin-top: 60px; /* Margin from the top for content alignment */
}
</style>
