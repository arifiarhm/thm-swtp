<template>
  <div>
    <nav class="menu" :class="{ 'menu-visible': menuVisible }">
      <div class="shadow-3 navbar-content">
        <div class="menu-links">
          <!-- Router-Links für Navigation -->
          <router-link to="/home" class="menu-link">Home</router-link>
          <router-link to="/editor" class="menu-link">Fragebogen-Editor</router-link>
          <router-link to="/questionnaires" class="menu-link">Fragebogenverwaltung</router-link>
          <a href="#" class="menu-link">Profil</a>
        </div>
      </div>
    </nav>
        <!-- Header mit Logo -->
    <header>
      <img src="@/assets/questionnaire.png" alt="Neues Logo" class="logo-in-menu" @click="closeMenu">
    </header>
     <!-- Überlagerung zum Schließen des Menüs -->
    <div class="menu-overlay" @click="menuVisible = false" v-show="menuVisible"></div>
    <!-- Werkzeugleiste mit Aktionsbuttons -->
    <div class="toolbar">
      <button @click="selectAction('edit')" class="action-button">
        <i class="fas fa-edit"></i> Bearbeiten
      </button>
      <button @click="selectAction('download')" class="action-button">
        <i class="fas fa-download"></i> Herunterladen
      </button>
      <button @click="selectDeleteAction" class="action-button" :disabled="frageboegen.length === 0">
        <i class="fas fa-trash-alt"></i> Löschen
      </button>
    </div>

       <!-- Tabelle zur Anzeige von Fragebögen -->
       
    <div class="frageboegen-table">
      <table v-if="frageboegen.length > 0"> 
        <thead>
          <tr>
            <th>Fragebogen ID</th>
            <th>Fragebogen Daten</th>
            <th>Benutzer ID</th>
            <th>Erstellt am</th>
            <th>Aktualisiert am</th>
          </tr>
        </thead>
        <tbody>
          <!-- Anzeige der Fragebogen-Daten in Zeilen -->
          <tr v-for="(fragebogen, index) in frageboegen" :key="index" @click="selectRow(index)" :class="{ 'selected-row': selectedRow === index }" @mouseover="hoverRow(index)" @mouseout="unhoverRow(index)">
            <td>{{ fragebogen.questionnaire_id }}</td>
            <td>{{ truncate( JSON.stringify(fragebogen.questionnaire_data,null, 2), 20) }}</td>
            <td>{{ fragebogen.user_id }}</td>
            <td>{{ fragebogen.createdAt }}</td>
            <td>{{ fragebogen.updatedAt }}</td>
          </tr>
        </tbody>
      </table>
       <!-- Anzeige einer Nachricht, wenn keine Fragebögen vorhanden sind -->
      <div v-else>
        <p>Keine Fragebögen vorhanden.</p>
      </div>
    </div>
    
        <!-- Dialog zum Löschen -->
    <div v-if="selectedAction === 'delete'" class="delete-dialog">
      <p>Möchten Sie den ausgewählten Fragebogen wirklich löschen?</p>
      <button @click="confirmDelete">Ja, löschen</button>
      <button @click="cancelDelete">Abbrechen</button>
    </div>
      <!-- Anzeige der Details des ausgewählten Fragebogens -->
    <div v-if="selectedRow !== null" class="questionnaire-details">
      <h2>Details des ausgewählten Fragebogens</h2>
      <p><strong>Fragebogen ID:</strong> {{ frageboegen[selectedRow].questionnaire_id }}</p>
      <p><strong>Fragebogen Daten:</strong> <pre class = 'json'>{{ JSON.stringify(JSON.parse(frageboegen[selectedRow].questionnaire_data), null, 2)}}</pre></p>
      <p><strong>Benutzer ID:</strong> {{ frageboegen[selectedRow].user_id }}</p>
      <p><strong>Erstellt am:</strong> {{ frageboegen[selectedRow].createdAt }}</p>
      <p><strong>Aktualisiert am:</strong> {{ frageboegen[selectedRow].updatedAt }}</p>
    </div>

    <footer>
      <p>© 2024 Questionnaire Responder Projekt | Gruppe 3 | Technische Hochschule Mittelhessen (THM)</p>
    </footer>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
      // Initiale Daten-Properties
    return {
      menuVisible: false,
      selectedAction: null,
      selectedRow: null,
      frageboegen: [],
      questionnaireData: null,
    };
  },
  methods: {
    toggleMenu() {
       // Methoden für die Menü- und Aktionssteuerung
      this.menuVisible = !this.menuVisible;
    },
    // Kommentare auf Deutsch für verschiedene Methoden

// Methode zum Schließen des Menüs
closeMenu() {
  this.menuVisible = false;
},

// Methode zur Auswahl einer Aktion
selectAction(action) {
  this.selectedAction = action;
},

// Methode zur Auswahl einer Zeile
selectRow(index) {
  this.selectedRow = index;
  this.fetchSelectedQuestionnaireData();
},

// Methode für Mausüber-Effekt auf Zeile
hoverRow(index) {
  console.log(`Maus über Zeile ${index}.`);
},

// Methode für Mausaus-Effekt auf Zeile
unhoverRow(index) {
  console.log(`Maus nicht mehr über Zeile ${index}.`);
},

// Methode zur Bestätigung des Löschens
confirmDelete() {
  if (this.selectedRow !== null) {
    const qidToDelete = this.frageboegen[this.selectedRow].questionnaire_id;
    this.deleteQuestionnaire(qidToDelete);
  }
},

// Methode zum Abbrechen des Löschens
cancelDelete() {
  this.selectedAction = null;
},

// Async-Methode zum Löschen eines Fragebogens
async deleteQuestionnaire(qid) {
  const serverURL = 'http://localhost:5001';
  const token = localStorage.getItem('token');
  try {
    await axios.delete(`${serverURL}/delete/${qid}`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    console.log('Fragebogen erfolgreich gelöscht.');
    await this.fetchQuestionnaires();
    this.selectedAction = null;
    this.selectedRow = null;
  } catch (error) {
    console.error('Fehler beim Löschen:', error);
  }
},

// Async-Methode zum Abrufen von Fragebogendaten
async fetchQuestionnaireData(qid) {
  try {
    const token = localStorage.getItem('token');
    const response = await axios.get(`http://localhost:5001/api/questionnaires/${qid}/data-representation`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    this.questionnaireData = response.data;
    this.questionnaireData.questionnaireId = qid;
  } catch (error) {
    console.error('Fehler beim Abrufen der Fragebogendaten:', error);
  }
},

// Async-Methode zum Abrufen aller Fragebögen
async fetchQuestionnaires() {
  const serverURL = 'http://localhost:5001';
  const token = localStorage.getItem('token');
  try {
    const response = await axios.get(`${serverURL}/api/questionnaires`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    this.frageboegen = response.data.data;
    console.log(this.frageboegen); // Überprüfe die Daten in der Konsole
  } catch (error) {
    if (error.response) {
      console.error('Fehler beim Abrufen der Fragebögen:', error.response.status, error.response.data);
    } else if (error.request) {
      console.error('Fehler beim Abrufen der Fragebögen: Keine Antwort erhalten');
    } else {
      console.error('Fehler beim Abrufen der Fragebögen:', error.message);
    }
  }
},

// Weitere Methoden für das Bearbeiten von Antworten, Abrufen von Antworten und Einreichen von Antworten
  },
// Lifecycle-Hook zum initialen Laden von Daten und Aktionen
created() {
  const questionnaireId = '123';  
  const answerId = '456'; 
  const answers = [{ questionId: 'q1', answerValue: 'Answer 1' }];
  const updatedAnswers = [{ questionId: 'q1', answerValue: 'Updated Answer 1' }];

  this.fetchQuestionnaires();
  this.deleteAnswer(questionnaireId, answerId);
  this.fetchAnswersForQuestionnaire(questionnaireId);
  this.submitAnswersForQuestionnaire(questionnaireId, answers);
  this.editAnswersForQuestionnaire(questionnaireId, answerId, updatedAnswers);
  },
};

</script>
/* Allgemeine Stilanpassungen für den gesamten Body */


<style scoped>
body {
  font-family: 'Open Sans Condensed', sans-serif;
  font-size: 16px;
  margin: 0;
  padding: 0;
  background-color: white;
  overflow-x: hidden;
}
/* Header-Stil */
header {
  background-color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0;
  margin: 0;
  border-bottom: 1px solid #ccc;
}
/* Stil für das Logo im Menü */
.logo-in-menu {
  max-height: 70px;
  width: auto;
  margin: 5px auto;
}
/* Stil für Menü-Links */
.menu-link {
  color: white;
  text-decoration: none;
  font-size: 16px;
  margin-left: 20px;
  position: relative;
  display: flex;
  align-items: center;
}
/* Hover-Effekt für Menü-Links */
.menu-link:hover {
  background-color: transparent !important;
  color: white;
}
/* Stil für das Hauptmenü */
.menu {
  display: flex;
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  background-color: #3581E5;
  padding: 6px;
  z-index: 2;
}
/* Stil für den Inhalt der Navigationsleiste */
.navbar-content {
  width: 100%;
  display: flex;
  justify-content: space-between;
  margin: 0;
  padding: 0;
}
/* Stil für Menü-Links außerhalb des Hauptmenüs */
.menu a {
  color: black;
  text-decoration: none;
  font-size: 17px;
}
/* Hover-Effekt für Menü-Links außerhalb des Hauptmenüs */
.menu a:hover {
  background-color: #ddd;
  color: white;
}
/* Stil für sichtbares Menü */
.menu-visible {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}
/* Stil für Aktionsschaltflächen */
.action-button {
  background-color: #5CA8FF;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  display: flex;
  align-items: center;
  margin: 0 5px;
}
/* Hover-Effekt für Aktionsschaltflächen */
.action-button:hover {
  background-color: #4080D6;
}
/* Stil für die Toolbar */
.toolbar {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 10px;
}
/* Stil für die Tabelle der Fragebögen */
.frageboegen-table table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  overflow-x: auto;
}
/* Stil für Tabellenzellen in der Tabelle der Fragebögen */
.frageboegen-table th, .frageboegen-table td {
  border: 1px solid #ddd;
  padding: 12px;
  text-align: center;
}
/* Hintergrundfarbe für Tabellenkopfzellen */
.frageboegen-table th {
  background-color: #f2f2f2;
}
/* Hintergrundfarbe für ausgewählte Zeilen */
.selected-row {
  background-color: #e6f7ff;
}
/* Stil für den Hauptinhalt */
main {
  padding: 20px;
  background-color: white;
}
/* Stil für den Footer */
footer {
  background-color: #eee;
  color: black;
  text-align: center;
  padding: 1em;
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
}
/* Stil für das Löschdialogfenster */
.delete-dialog {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: white;
  padding: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  z-index: 3;
  text-align: center;
}
/* Stil für Löschdialogfenster-Schaltflächen */
.delete-dialog button {
  background-color: #FF4D4D;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  margin: 0 5px;
}
/* Hover-Effekt für Löschdialogfenster-Schaltflächen */
.delete-dialog button:hover {
  background-color: #D63434;
}
/* Stil für die Details eines Fragebogens */
.questionnaire-details {
  padding: 20px;
  background-color: #f9f9f9;
  margin-top: 20px;
  border: 1px solid #ddd;
  border-radius: 5px;
  padding-bottom : 100px;

}

.questionnaire-details .json{
  text-align: left;
}

</style>
