<template>
  <!-- Conditional rendering of registration form -->
  <div v-if="showRegistration && !profileVisible" class="login-box">
    <!-- Questionnaire Logo and welcome message -->
    <div class="align-left">
      <img src="@/assets/questionnaire.png" alt="Questionnaire Logo" class="logo" style="max-height: 60px; width: auto;">
      <h2 style="color: #3581E5;">Registrierung</h2>
    </div>
    <!-- Registration form -->
    <form @submit.prevent="register">
      <!-- Input fields for email, full name, password, and password confirmation -->
      <div class="input-group">
        <label for="newUsername" style="color: #000000; text-align: left;">E-Mail-Adresse:</label>
        <input type="text" v-model="newUsername" id="newUsername" required>
      </div>
      <div id="input-group">
        <label for="fullName" style="color: #000000; text-align: left;">Vor- & Nachname:</label>
        <input type="text" v-model="fullName" id="fullName" required>
      </div>
      <div class="input-group">
        <label for="newPassword" style="color: #000000; text-align: left;">Passwort:</label>
        <!-- Password input field with show/hide button -->
        <div class="password-input-group">
          <input
            :type="newPasswordVisible ? 'text' : 'password'"
            :style="{ borderColor: passwordBorderColor }"
            v-model="newPassword"
            id="newPassword"
            required
            @input="checkPasswordStrength"
          />
          <button @mousedown="showNewPassword" @mouseup="hideNewPassword" @mouseleave="hideNewPassword" type="button" class="eye-button">
            <img v-if="newPasswordVisible" src="https://img.icons8.com/material-sharp/24/000000/visible.png" alt="Show" />
            <img v-else src="https://img.icons8.com/material-sharp/24/000000/invisible.png" alt="Hide" />
          </button>
        </div>
      </div>
      <div class="input-group">
        <label for="confirmPassword" style="color: #000000; text-align: left;">Passwort wiederholen:</label>
        <!-- Confirm password input field with show/hide button -->
        <div class="password-input-group">
          <input
            :type="confirmPasswordVisible ? 'text' : 'password'"
            :style="{ borderColor: confirmPasswordBorderColor }"
            v-model="confirmPassword"
            id="confirmPassword"
            required
          />
          <button @mousedown="showConfirmPassword" @mouseup="hideConfirmPassword" @mouseleave="hideConfirmPassword" type="button" class="eye-button">
            <img v-if="confirmPasswordVisible" src="https://img.icons8.com/material-sharp/24/000000/visible.png" alt="Show" />
            <img v-else src="https://img.icons8.com/material-sharp/24/000000/invisible.png" alt="Hide" />
          </button>
        </div>
      </div>

      <!-- Error messages -->
      <div class="password-strength" :class="passwordStrength" v-if="isPasswordValid(newPassword)">
        Passwort erfüllt alle Anforderungen.
      </div>

      <!-- Password strength indicator -->
      <div id="password-strength" style="margin-top: 20px;">
        <div id="strength-bar"></div>
      </div>

      <!-- Registration button -->
      <button type="submit" style="background-color: #5CA8FF; text-align: left; margin-left: 0; margin-right: auto; margin-top: 10px; display: block;">Registrieren</button>
    </form>

    <!-- Link to login page -->
    <div style="text-align: center; margin-top: 20px;">
      <router-link to="/login" style="color: #3581E5; cursor: pointer; text-decoration: none;">Bereits registriert? Hier anmelden.</router-link>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      showRegistration: true,
      profileVisible: false,
      newUsername: '',
      fullName: '',
      newPassword: '',
      newPasswordVisible: false,
      confirmPassword: '',
      confirmPasswordVisible: false,
      passwordBorderColor: '',
      confirmPasswordBorderColor: '',
      passwordRequirements: {
        length: false,
        uppercase: false,
        specialChar: false,
      },
      errorMessage: '', // Added for error message
    };
  },

  methods: {
    // Method for user registration
    register() {
      // Check if passwords match and meet requirements
      if (this.newPassword === this.confirmPassword && this.isPasswordValid(this.newPassword) && this.isEmailValid(this.newUsername)) {
        // Create data object with registration information
        const userData = {
          email: this.newUsername,
          fullName: this.fullName,
          password: this.newPassword,
        };

        // Log the data to be sent to the server
        console.log('Sending data to server:', userData);

        // Set server URL based on environment (localhost only)
        const serverURL = 'http://localhost:5001';

        // Send a POST request to the server's registration endpoint
        axios.post(`${serverURL}/register`, userData)
          .then(response => {
            // Successful registration
            console.log('Server Response:', response);
            alert(response.data.message);
          })
          .catch(error => {
            // Registration failed
            console.error('Registration failed:', error);
            this.errorMessage = 'Registration failed. Check the console for details.';
          });
      } else {
        // Display an error message if registration conditions are not met
        this.errorMessage = 'Passwords do not match or do not meet requirements, or the email address is invalid.';
      }
    },

    // Check password requirements
    isPasswordValid(password) {
      const lengthRequirement = password.length >= 8;
      const uppercaseRequirement = /[A-Z]/.test(password);
      const specialCharRequirement = /[!@#$%^&*(),.?":{}|<>]/.test(password);
      this.passwordRequirements.length = lengthRequirement;
      this.passwordRequirements.uppercase = uppercaseRequirement;
      this.passwordRequirements.specialChar = specialCharRequirement;
      return lengthRequirement && uppercaseRequirement && specialCharRequirement;
    },

    // Check validity of email address
    isEmailValid(email) {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailPattern.test(email);
    },

    // Show password
    showNewPassword() {
      this.newPasswordVisible = true;
    },

    // Hide password
    hideNewPassword() {
      this.newPasswordVisible = false;
    },

    // Show confirm password
    showConfirmPassword() {
      this.confirmPasswordVisible = true;
    },

    // Hide confirm password
    hideConfirmPassword() {
      this.confirmPasswordVisible = false;
    },

    // Function to check password strength
    checkPasswordStrength() {
      // Get password from input field
      var password = this.newPassword;
      // Get password strength element
      var strengthElement = document.getElementById('strength-bar');

      // Check minimum length
      var lengthError = password.length < 8;

      // Check if password contains uppercase letters
      var uppercaseError = !/[A-Z]/.test(password);

      // Check if password contains lowercase letters
      var lowercaseError = !/[a-z]/.test(password);

      // Check if password contains digits
      var digitError = !/\d/.test(password);

      // Check if password contains special characters
      var specialCharError = !/[!@#$%^&*(),.?":{}|<>]/.test(password);

      // Calculate overall password strength score
      var passwordStrength = 5;
      if (lengthError) passwordStrength--;
      if (uppercaseError) passwordStrength--;
      if (lowercaseError) passwordStrength--;
      if (digitError) passwordStrength--;
      if (specialCharError) passwordStrength--;

      // Calculate percentage password strength
      var strengthPercentage = (passwordStrength / 5) * 100;
      // Display password strength in progress bar
      strengthElement.style.width = strengthPercentage + '%';

      // Set progress bar color based on password strength
      if (passwordStrength === 5) {
        strengthElement.style.backgroundColor = 'green';
      } else if (passwordStrength >= 3) {
        strengthElement.style.backgroundColor = 'orange';
      } else {
        strengthElement.style.backgroundColor = 'red';
      }
    },
  },
};
</script>

<style scoped>
  /* Variables for colors */
  :root {
    --primary-color: #3581E5;
    --secondary-color: #ffffff;
    --background-color: #f4f4f4;
  }

  /* Global styles for the entire body */
  body {
    font-family: Arial, sans-serif;
    background-color: var(--background-color);
    margin: 0;
  }

  /* Styles for the registration box */
  .login-box {
    max-width: 400px;
    margin: 0 auto;
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  /* Styles for labels and inputs in the registration box */
  .login-box label,
  .login-box input {
    display: block;
    width: 100%;
    margin-bottom: 10px;
  }

  /* Styles for the password input field and eye button */
  .password-input-group {
    position: relative;
  }

  .eye-button {
    cursor: pointer;
    background: none;
    border: none;
    position: absolute;
    right: 0px;
    top: 60%;
    transform: translateY(-50%);
  }

  /* Styles for input groups */
  .input-group {
    margin-bottom: 15px;
  }

  /* Styles for the password strength display */
  #password-strength {
    margin-top: 10px;
    height: 10px;
    border: 1px solid #ccc;
    position: relative;
    width: 100%;
  }

  #strength-bar {
    height: 100%;
    width: 0;
    background-color: #ddd;
    position: absolute;
    top: 0;
    left: 0;
  }
</style>
