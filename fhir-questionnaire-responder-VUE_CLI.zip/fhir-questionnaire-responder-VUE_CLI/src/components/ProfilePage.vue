<template>
  <div>
    <!-- Navigation Bar -->
    <nav class="menu" :class="{ 'menu-visible': menuVisible }">
      <div class="shadow-3 navbar-content">
        <div class="menu-links">
          <!-- Home-Link -->
          <router-link to="/home" class="menu-link">Home</router-link>
          <!-- Link für den Fragebogen-Editor -->
          <router-link to="/editor" class="menu-link">Fragebogen-Editor</router-link>
          <!-- Link für die Fragebogenverwaltung -->
          <router-link to="/questionnaires" class="menu-link">Fragebogenverwaltung</router-link>
          <!-- Profil-Link -->
          <router-link to="/profile" class="menu-link">Profil</router-link>
        </div>
      </div>
    </nav>

     <!-- Logout Button -->
    <button @click="logout" class="logout-button">
      <i class="fas fa-sign-out-alt"></i> Abmelden
    </button>

    <!-- Hauptcontainer -->
    <div class="container">
      <!-- Profile Box -->
      <div v-if="showProfile && !showRegistration" class="profile-box">
        <!-- Questionnaire Logo and Welcome Message -->
        <div class="align-left">
          <img src="@/assets/questionnaire.png" alt="Questionnaire Logo" class="logo" style="max-height: 80px; width: auto;">
          <h2 style="color: var(--primary-color);">Benutzerprofil</h2>
        </div>


         <!-- Passwort ändern Button -->
    <button
      @click="showResetPasswordPopup"
      :class="{ 'reset-password-button-disabled': showResetPassword }"
    >
      <i class="fas fa-key"></i> Passwort ändern
    </button>

    <!-- Passwort ändern Popup -->
    <div v-if="showResetPassword" class="reset-password-popup">
       

      <h2>Passwort zurücksetzen</h2>

      <!-- Altes Passwort Input -->
      <div class="form-group">
        <label for="oldPassword" class="input-label">Altes Passwort:</label>
        <div class="input-container">
          <input type="password" id="oldPasswordReset" v-model="oldPassword" class="input-field">
        </div>
      </div>

      <!-- Neues Passwort Input -->
      <div class="form-group">
        <label for="newPassword" class="input-label">Neues Passwort:</label>
        <div class="input-container">
          <input type="password" id="newPasswordReset" v-model="newPassword" class="input-field">
        </div>
      </div>

      <!-- Passwortbestätigung Input -->
      <div class="form-group">
        <label for="confirmNewPassword" class="input-label">Passwort bestätigen:</label>
        <div class="input-container">
          <input type="password" id="confirmPasswordReset" v-model="confirmNewPassword" class="input-field">
        </div>
      </div>
      
      <!-- Button zum Auslösen des Passwort zurücksetzen -->
      <button @click="resetPassword" class="reset-password-button">
        <i class="fas fa-key"></i> Passwort ändern
      </button>
    </div>
      <!-- Schließen-Button im Popup -->
      <button @click="closeResetPasswordPopup" class="close-popup-button">
        <i class="fas fa-times"></i> Schließen
      </button>
    </div>

          <!-- Bestätigungsdialog für Benutzerkonto löschen -->
    <div v-if="showDeleteConfirmation" class="delete-dialog">
      <p>Sind Sie sicher, dass Sie Ihr Benutzerkonto löschen möchten?</p>
</div>

      

      <button @click="deleteAccount" class="delete-account-button">
        <i class="fas fa-trash"></i> Benutzerkonto löschen
      </button>

      
  

      <!-- Registration Box -->
      <div v-if="showRegistration && !showProfile" class="registration-box">
        <!-- Registration Form (Use your existing code here) -->
        <!-- ... -->
      </div>
    </div>

    <!-- Footer-Bereich (verwendet das Design der HomePage) -->
    <footer>
      <!-- Copyright-Information -->
      <p>© 2024 Questionnaire Responder Projekt | Gruppe 3 | Technische Hochschule Mittelhessen (THM)</p>
    </footer>
  </div>
</template>

<script>
  import axios from 'axios';
export default {
  data() {
    return {
      showProfile: true,
      showRegistration: false,
      showDeleteConfirmation: false,
      menuVisible: false,
      oldPassword: '',
      newPassword: '',
      confirmNewPassword: '',
      showResetPassword: false,
      password:'',
      confPassword:'',
    };
  },
  methods: {

     // Passwort zurücksetzen anzeigen
    showResetPasswordPopup() {
      this.showResetPassword = true;
    },

    // Passwort zurücksetzen schließen
    closeResetPasswordPopup() {
      this.showResetPassword = false;
      // Zurücksetzen der Eingabefelder beim Schließen des Pop-ups
      this.oldPassword = '';
      this.newPassword = '';
      this.confirmNewPassword = '';
    },

     // Logout-Methode
    logout() {
      const token = localStorage.getItem('token');
      const endpoint = 'http://localhost:5001/logout'; // Setze den tatsächlichen Logout-Endpoint ein

      axios.delete(endpoint, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then(response => {
        console.log('Abmeldung erfolgreich:', response.data);
        alert('Abmeldung erfolgreich');

        // Löscht den Token aus dem localStorage und leitet den Benutzer zur Login-Seite weiter
        localStorage.removeItem('token');
        this.$router.push('/login');
      })
      .catch(error => {
        console.error('Fehler bei der Abmeldung:', error);
        alert('Fehler bei der Abmeldung. Überprüfe die Konsole für Details.');
      });
    },
       resetPassword() {
      // neue Passwort und die Bestätigung müssen übereinstimmen
      if (this.newPassword !== this.confirmNewPassword) {
        alert('Das neue Passwort und die Bestätigung stimmen nicht überein.');
        return;
      }

      console.log("Altes Passwort:", this.oldPassword);
      console.log("Neues Passwort:", this.newPassword);
      console.log("Passwort bestätigen:", this.confirmNewPassword);

      // Endpoint Anbindung
      const endpoint = 'http://localhost:5001/change-password';
      const token = localStorage.getItem('token');

      // Passwortänderung
      axios.post(endpoint, {
        oldPassword: this.oldPassword,
        newPassword: this.newPassword,
       confirmNewPassword: this.confirmNewPassword,
      }, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then(response => {
        console.log('Passwort erfolgreich geändert:', response.data);
        alert('Passwort erfolgreich geändert');
        
      })
      .catch(error => {
        console.error('Fehler bei der Passwortänderung:', error);
        alert('Fehler bei der Passwortänderung. Überprüfe die Konsole für Details.');
      });
    },
      toggleMenu() {
      this.menuVisible = !this.menuVisible;
    },
    closeMenu() {
      this.menuVisible = false;
    },
    confirmDeleteAccount() {
      // Bestätigungsdialog anzeigen
      this.showDeleteConfirmation = true;
    },
    
    //methode zum delete acc
     deleteAccount() {
      if (this.Password !== this.confPassword) {
        alert('Das eingegebene Passwort zur Bestätigung ist nicht korrekt.');
        return;
      }

    // Endpoint zur Kontolöschung
      const endpoint = 'http://localhost:5001/delete-account';

      axios.delete(endpoint, {
        deleteData: {
        Password: this.Password,
        confPassword: this.confPassword,
          
        },
        headers: {
          Authorization: `Bearer ${this.$store.state.accessToken}`,
        },
      })
      .then(response => {
        console.log('Benutzerkonto erfolgreich gelöscht:', response.data);
        alert('Benutzerkonto erfolgreich gelöscht');
        this.showDeleteConfirmation = false;
      })
      .catch(error => {
        console.error('Fehler beim Löschen des Benutzerkontos:', error);
        alert('Fehler beim Löschen des Benutzerkontos. Überprüfe die Konsole für Details.');
        this.showDeleteConfirmation = false;
      });
    },
    cancelDelete() {
      // Den Bestätigungsdialog ausblenden
      this.showDeleteConfirmation = false;
    },
  },
};
</script>

<style scoped>
  /* Variables for colors */
  :root {
    --primary-color: #3581E5;
    --secondary-color: #ffffff;
    --background-color: #f4f4f4;
  }

  /* Global styles for the entire body */
  body {
    font-family: Arial, sans-serif;
    background-color: var(--background-color);
    margin: 0;
  }
   .form-group {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
  }
   .close-popup-button {
    background-color: #ccc;
    color: #333;
    padding: 10px 15px;
    font-size: 14px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 15px;
  }
.reset-password-button-disabled {
    background-color: #ccc; /* Graue Hintergrundfarbe */
    color: #666; /* Dunklerer Text */
    cursor: not-allowed; /* Mauszeiger nicht erlaubt */
  }

.close-popup-button:hover {
  background-color: #ddd;
}

  .input-label {
    width: 150px;
    margin-right: 15px;
    text-align: right;
  }

  .input-container {
    flex: 1;
  }

  .input-field {
    width: 100%;
    padding: 8px;
    box-sizing: border-box;
  }

  .menu-link {
    color: white;
    text-decoration: none;
    font-size: 16px;
    margin-left: 20px;
    position: relative;
    display: flex;
    align-items: center;
  }

  .menu-link:hover {
    background-color: transparent !important;
    color: white;
  }

  .menu {
    display: flex;
    position: fixed;
    top: 0;
    right: 0;
    left: 0;
    background-color: #3581E5;
    padding: 6px;
    z-index: 2;
  }

  .navbar-content {
    width: 100%;
    display: flex;
    justify-content: space-between;
    margin: 0;
    padding: 0;
  }

  .menu a {
    color: black;
    text-decoration: none;
    font-size: 17px;
  }

  .menu a:hover {
    background-color: #ddd;
    color: white;
  }

  .menu-visible {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
  }

  /* Styles for the Passwort zurücksetzen button */
  .reset-password-button {
    background-color: #5CA8FF;
    color: white;
    padding: 10px 15px;
    font-size: 14px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 15px; 
  }

  .reset-password-button:hover {
  background-color: #4080D6;
  }

  .nav-item {
    cursor: pointer;
  }

  /* Styles for the profile box */
  .profile-box,
  .registration-box {
    max-width: 400px;
    margin: 0 auto;
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  /* Styles for profile content */
  .profile-content {
    margin-top: 15px;
  }

  /* Styles for labels and inputs in the profile box */
  .profile-box p {
    margin-bottom: 10px;
    color: #000000;
  }

  /* Styles for the link to the registration page */
  .profile-box a {
    color: var(--primary-color);
    cursor: pointer;
    text-decoration: none;
  }

  .delete-account-button {
    background-color: #FF4D4D;
    color: white;
    padding: 10px 15px;
    font-size: 14px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 15px;
  }

  .delete-account-button:hover {
    background-color: #D63434;
  } 

  .delete-dialog {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: white;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    z-index: 3;
    text-align: center;
  }

  .delete-dialog button {
    background-color: #FF4D4D;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    margin: 0 5px;
  }

  .delete-dialog button:hover {
    background-color: #D63434;
  }

  .logout-button {
  position: fixed;
  top: 20px;
  right: 10px;
  background-color: #FF4D4D;
  color: white;
  padding: 10px 15px;
  font-size: 14px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.logout-button:hover {
  background-color: #D63434;
}
</style>
