<template>
  <div class="password-forgot">
    <!-- Logo für die Passwort-vergessen-Seite -->
    <div class="align-left">
      <img src="@/assets/questionnaire.png" alt="Questionnaire Logo" class="logo" style="max-height: 80px; width: auto;">
    </div>
    <!-- Überschrift für die Passwort-vergessen-Seite -->
    <h2>Passwort vergessen</h2>
    <!-- Formular für die Passwort-zurücksetzen-Anfrage -->
    <form @submit.prevent="submitForm">
      <!-- Eingabefeld für die E-Mail-Adresse -->
      <div class="input-group">
        <label for="email">Deine E-Mail-Adresse:</label>
        <input type="email" v-model="email" id="email" required>
      </div>
      <!-- Link zum Zurückkehren zum Login -->
      <div class="align-left" style="margin-bottom: 20px;">
        <router-link to="/login" style="color: #3581E5; cursor: pointer; text-decoration: none;">
          Zurück zum Login
        </router-link>
      </div>
      <!-- Button zum Absenden des Passwort-zurücksetzen-Formulars -->
      <button type="submit" style="background-color: #5CA8FF; text-align: left; margin-left: 0;">Passwort zurücksetzen</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    return {
      email: '',
    };
  },
  methods: {
    submitForm() {
      const requestData = {
        email: this.email,
      };

      axios.post('http://localhost:5001/forget-password', requestData)
        .then(response => {
          console.log('Anfrage zum Zurücksetzen des Passworts erfolgreich gesendet:', response.data);
          // Fügen Sie hier zusätzliche Aktionen nach erfolgreicher Anfrage hinzu, z.B. Anzeige einer Bestätigungsmeldung
        })
        .catch(error => {
   console.error('Fehler beim Senden der Anfrage zum Zurücksetzen des Passworts:', error);
   if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
      console.error('Response headers:', error.response.headers);
   } else if (error.request) {
      // The request was made but no response was received
      console.error('Request data:', error.request);
   } else {
      // Something happened in setting up the request that triggered an Error
      console.error('Error message:', error.message);
   }
});

    },
    
  }
};
</script>

<style>
/* Stile für die Passwort-vergessen-Seite */
.password-forgot {
  max-width: 400px;
  margin: 0 auto;
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Stile für Labels und Inputfelder auf der Passwort-vergessen-Seite */
.password-forgot label,
.password-forgot input {
  display: block;
  width: 100%;
  margin-bottom: 10px;
}

/* Stile für das Logo auf der Passwort-vergessen-Seite */
.password-forgot .logo {
  max-height: 60px;
  width: auto;
}

/* Allgemeine Button-Stile */
button {
    background-color: #5CA8FF;
    color: white;
    padding: 10px 15px;
    font-size: 14px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 15px; 
}
</style>
