<template>
  <div>
    <!-- Navigation Bar -->
    <nav class="menu" :class="{ 'menu-visible': menuVisible }">
      <div class="shadow-3 navbar-content">
        <div class="menu-links">
          <!-- Navigation Links -->
          <router-link to="/home" class="menu-link">Home</router-link>
          <router-link to="/editor" class="menu-link">Fragebogen-Editor</router-link>
          <router-link to="/questionnaires" class="menu-link">Fragebogenverwaltung</router-link>
          <router-link to="/profile" class="menu-link">Profil</router-link>
        </div>
      </div>
    </nav>

    <!-- Header Section -->
    <header>
      <!-- Logo with Click Event to Close Menu -->
      <img src="@/assets/questionnaire.png" alt="Questionnaire Logo" class="logo-in-menu" @click="closeMenu">
    </header>

    <!-- Menu Overlay (visible when menu is open) -->
    <div class="menu-overlay" @click="menuVisible = false" v-show="menuVisible"></div>

    <!-- Main Content Section -->
    <div>
      <!-- HTML Document Title and External Stylesheet Link -->
      <title>Questionnaire Response Generator</title>
      <link rel="stylesheet" href="styles.css">

      <!-- Main Heading -->
      <h1>Fragebogen</h1>

      <!-- File Input and Load Questionnaire Button -->
      <input type="file" id="questionnaireFile" accept=".json">
      <button @click="loadQuestionnaire">Fragebogen Laden</button>

      <!-- Dynamic Form Fields -->
      <form id="questionnaireForm" style="display: none;">
        <!-- Form Fields will be dynamically inserted here -->
      </form>

      <!-- Submit Questionnaire Button -->
      <button @click="generateResponse">Fragebogen Abschicken</button>

      <!-- Download Button and Response Table -->
      <a id="downloadLink" :href="downloadUrl" download="QuestionnaireResponse.json">
        <button class="download-button" v-show="downloadUrl !== ''">Hier klicken, um die Antwort herunterzuladen</button>
      </a>

      <!-- Response Table Section -->
      <div id="answers" v-if="responseData && responseData.item.length > 0">
        <h2>Antworten</h2>
        <!-- Table for Displaying Questions and Answers -->
        <table id="responseTable" class="response-table">
          <thead>
            <tr>
              <th style="border: 1px solid #ddd; padding: 12px; background-color: #f2f2f2; text-align: left;">Frage</th>
              <th style="border: 1px solid #ddd; padding: 12px; background-color: #f2f2f2; text-align: left;">Antwort</th>
            </tr>
          </thead>
          <tbody>
            <!-- Loop through Response Data to Populate Table Rows -->
            <tr v-for="(item, index) in responseData.item" :key="index">
              <td>{{ getQuestionText(item.linkId) }}</td>
              <td>{{ getAnswerText(item) }}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Footer Section -->
      <footer>
        <p>© 2024 Questionnaire Responder Projekt | Gruppe 3 | Technische Hochschule Mittelhessen (THM)</p>
      </footer>
    </div>
  </div>
</template>


<script>
export default {
  data() {
    // Data Properties for Component State
    return {
      menuVisible: false,
      questionnaireData: {}, // Holds loaded questionnaire data
      downloadUrl: '',      // URL for downloading response as JSON
      responseData: null,    // Holds generated response data
    };
  },
  methods: {
    // Method to retrieve question text based on linkId
    getQuestionText(linkId) {
      const question = this.questionnaireData.item.find(q => q.linkId === linkId);
      return question ? question.text : '';
    },

    // Method to retrieve answer text from the response item
    getAnswerText(item) {
      if (item.answer && item.answer[0]) {
        return item.answer[0].valueString || item.answer[0].valueCoding.display || 'Nicht beantwortet';
      } else {
        return 'Nicht beantwortet';
      }
    },

    // Method to load a questionnaire from a JSON file
    loadQuestionnaire() {
      const fileInput = document.getElementById('questionnaireFile');
      const file = fileInput.files[0];

      if (file) {
        const reader = new FileReader();

        // Callback when file is loaded
        reader.onload = (e) => {
          this.questionnaireData = JSON.parse(e.target.result);
          this.renderQuestionnaireForm();
        };

        reader.readAsText(file); // Read file as text
      }
    },

    // Method to render the questionnaire form dynamically
    renderQuestionnaireForm() {
      const form = document.getElementById('questionnaireForm');
      form.innerHTML = '';

      // Loop through questionnaire items and create form fields
      this.questionnaireData.item.forEach(item => {
        const field = this.createFormField(item);
        form.appendChild(field);
      });

      form.style.display = 'block';
    },

    // Method to create a form field based on the questionnaire item
    createFormField(item) {
      const field = document.createElement('div');

      // Check the type of the item and create corresponding form elements
      if (item.type === 'integer' || item.type === 'boolean' || item.type === 'choice') {
        const question = document.createElement('label');
        question.innerText = item.text;
        field.appendChild(question);

        if (item.type === 'integer' || item.type === 'boolean') {
          const input = document.createElement(item.type === 'integer' ? 'input' : 'select');
          input.name = item.linkId;

          // Use custom attribute 'data-type' to store the type
          input.setAttribute('data-type', item.type);

          // Create options for boolean type
          if (item.type === 'boolean') {
            const option = document.createElement('option');
            option.value = '';
            option.text = 'Bitte auswählen';
            input.appendChild(option);

            const trueOption = document.createElement('option');
            trueOption.value = 'true';
            trueOption.text = 'Ja';
            input.appendChild(trueOption);

            const falseOption = document.createElement('option');
            falseOption.value = 'false';
            falseOption.text = 'Nein';
            input.appendChild(falseOption);
          }

          field.appendChild(input);
        } else if (item.type === 'choice') {
          const select = document.createElement('select');
          select.name = item.linkId;

          // Use custom attribute 'data-type' to store the type
          select.setAttribute('data-type', item.type);

          // Create placeholder option
          const optionPlaceholder = document.createElement('option');
          optionPlaceholder.value = '';
          optionPlaceholder.text = 'Bitte auswählen';
          select.appendChild(optionPlaceholder);

          // Create options based on answer options
          item.answerOption.forEach(option => {
            const optionElement = document.createElement('option');
            optionElement.value = option.valueCoding.display;
            optionElement.text = option.valueCoding.display;
            select.appendChild(optionElement);
          });

          field.appendChild(select);
        }

        // Recursively create form fields for nested items
        if (item.item && item.item.length > 0) {
          item.item.forEach(subItem => {
            const subField = this.createFormField(subItem);
            field.appendChild(subField);
          });
        }
      }

      return field;
    },

    // Method to generate response based on user inputs in the form
    generateResponse() {
      const form = document.getElementById('questionnaireForm');
      const response = { resourceType: 'QuestionnaireResponse', item: [] };

      // Loop through questionnaire items and create response data
      this.questionnaireData.item.forEach(item => {
        const responseItem = { linkId: item.linkId };

        if (item.type === 'integer' || item.type === 'boolean') {
          const inputField = form.querySelector(`[name="${item.linkId}"]`);
          if (inputField && inputField.value !== '') {
            responseItem.answer = [{ valueString: inputField.value }];
          }
        } else if (item.type === 'choice') {
          const selectField = form.querySelector(`[name="${item.linkId}"]`);
          if (selectField && selectField.value !== '') {
            responseItem.answer = [{ valueString: selectField.value }];
          }
        }

        response.item.push(responseItem);
      });

      // Save the response in the component data
      this.responseData = response;

      // Create a JSON blob for downloading
      const blob = new Blob([JSON.stringify(response, null, 2)], { type: 'application/json' });
      this.downloadUrl = URL.createObjectURL(blob);

      // Display the generated answers
      this.displayAnswers();
    },

    // Method to display the generated answers in a table
    displayAnswers() {
      const answersTableBody = document.querySelector('#responseTable tbody');
      if (answersTableBody) {
        answersTableBody.innerHTML = '';

        // Check if there is response data
        if (this.responseData) {
          // Loop through response items and populate table
          this.responseData.item.forEach(item => {
            const row = answersTableBody.insertRow(-1);
            const cell1 = row.insertCell(0);
            cell1.innerText = this.questionnaireData.item.find(q => q.linkId === item.linkId).text;

            const cell2 = row.insertCell(1);
            if (item.answer && item.answer[0]) {
              cell2.innerText = item.answer[0].valueString;
            } else {
              cell2.innerText = 'Nicht beantwortet';
            }
          });
        }

        // Display the answers section
        const answersDiv = document.getElementById('answers');
        answersDiv.style.display = 'block';
      }
    },
  },
};
</script>


<style scoped>
  /* Styles for the response table */
  .response-table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 10px;
  }

  .response-table th,
  .response-table td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
  }

  .response-table th {
    background-color: #f2f2f2;
  }

  .response-table td {
    background-color: #fff;
  }

  .response-table tbody tr {
    border-bottom: 1px solid #ddd;
  }

  .response-table tbody tr:last-child {
    border-bottom: none;
  }

  .response-table tbody td:last-child {
    border-right: none;
  }

  /* General styling for the entire page */
  body {
    font-family: 'Open Sans Condensed', sans-serif;
    font-size: 16px;
    margin: 0;
    padding: 0;
    background-color: white;
    overflow-x: hidden;
  }

  /* Styling for the header section */
  header {
    background-color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0;
    margin: 0;
    border-bottom: 1px solid #ccc;
  }

  .logo-in-menu {
    max-height: 80px;
    width: auto;
    margin: 5px auto;
  }

  .menu-link {
    color: white;
    text-decoration: none;
    font-size: 16px;
    margin-left: 20px;
    position: relative;
    display: flex;
    align-items: center;
  }

  .menu-link:hover {
    background-color: transparent !important;
    color: white;
  }

  /* Styling for the navigation menu */
  .menu {
    display: flex;
    position: fixed;
    top: 0;
    right: 0;
    left: 0;
    background-color: #3581E5;
    padding: 6px;
    z-index: 2;
  }

  .navbar-content {
    width: 100%;
    display: flex;
    justify-content: space-between;
    margin: 0;
    padding: 0;
  }

  .menu a {
    color: black;
    text-decoration: none;
    font-size: 17px;
  }

  .menu a:hover {
    background-color: #ddd;
    color: white;
  }

  .menu-visible {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
  }

  .action-button {
    background-color: #5CA8FF;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    display: flex;
    align-items: center;
    margin: 0 5px;
  }

  .action-button:hover {
    background-color: #4080D6;
  }

  /* Styling for the main content section */
  main {
    padding: 20px;
    background-color: white;
  }

  /* Styling for the footer section */
  footer {
    background-color: #eee;
    color: black;
    text-align: center;
    padding: 1em;
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
  }

  /* Styling for the questionnaires and answers sections */
  .questionnaires {
    background-color: #ffffff;
    padding: 20px;
    margin: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    color: #333333;
    display: block;
  }

  .answers {
    margin-top: 20px;
  }

  /* Styling for the response table within answers section */
  #responseTable {
    border-collapse: collapse;
    width: 100%;
    margin-top: 10px;
  }

  #responseTable th,
  #responseTable td {
    border: 1px solid #ddd !important;
    padding: 12px;
    text-align: left;
  }

  #responseTable th {
    background-color: #f2f2f2;
  }

  #responseTable td {
    background-color: #fff;
  }

  #responseTable tbody tr {
    border-bottom: 1px solid #ddd !important;
  }

  #responseTable tbody tr:last-child {
    border-bottom: none !important;
  }

  #responseTable tbody td:last-child {
    border-right: none !important;
  }
</style>
