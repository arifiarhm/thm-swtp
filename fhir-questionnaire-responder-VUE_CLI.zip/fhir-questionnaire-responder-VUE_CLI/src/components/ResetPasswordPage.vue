<template>
  <div class="password-reset">
    <!-- Logo für die Passwort-zurücksetzen-Seite -->
    <div class="align-left">
      <img src="@/assets/questionnaire.png" alt="Questionnaire Logo" class="logo" style="max-height: 80px; width: auto;">
    </div>
    <!-- Überschrift für die Passwort-zurücksetzen-Seite -->
    <h2>Passwort zurücksetzen</h2>
    <!-- Formular für das Passwort zurücksetzen -->
    <form @submit.prevent="submitForm">
      <!-- Eingabefeld für das neue Passwort -->
      <div class="input-group">
        <label for="password">Neues Passwort:</label>
        <input type="password" v-model="newPassword" id="newPassword" required>
      </div>
      <!-- Eingabefeld zur Bestätigung des neuen Passworts -->
      <div class="input-group">
        <label for="confirmPassword">Passwort bestätigen:</label>
        <input type="password" v-model="confirmNewPassword" id="confirmNewPassword" required>
      </div>
      <!-- Link zum Zurückkehren zum Login -->
      <div class="align-left" style="margin-bottom: 20px;">
        <router-link to="/login" style="color: #3581E5; cursor: pointer; text-decoration: none;">
          Zurück zum Login
        </router-link>
      </div>
      <!-- Button zum Absenden des Passwort-zurücksetzen-Formulars -->
      <button type="submit" style="background-color: #5CA8FF; text-align: left; margin-left: 0;">Passwort zurücksetzen</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      newPassword: '',
      confirmNewPassword: '',
    };
  },
  methods: {
    submitForm() {
      if (this.newPassword !== this.confirmNewPassword) {
        console.error('Passwörter stimmen nicht überein');
        return;
      }

      const requestData = {
        newPassword: this.newPassword,
        confirmNewPassword: this.confirmNewPassword,
        resetToken: this.$route.query.token,
      };

      axios.post('http://localhost:5001/reset-password', requestData)
        .then(response => {
          console.log('Passwort erfolgreich zurückgesetzt:', response.data);
        
        })
        .catch(error => {
          console.error('Fehler beim Zurücksetzen des Passworts:', error);
          
        });
    },
  },
  mounted() {

    this.userId = this.$route.query.userId;
  }, 
};
</script>



<style scoped>
/* Stile für die Passwort-zurücksetzen-Seite */
.password-reset {
  max-width: 400px;
  margin: 0 auto;
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Stile für Labels und Inputfelder auf der Passwort-zurücksetzen-Seite */
.password-reset label,
.password-reset input {
  display: block;
  width: 100%;
  margin-bottom: 10px;
}

/* Stile für das Logo auf der Passwort-zurücksetzen-Seite */
.password-reset .logo {
  max-height: 60px;
  width: auto;
}

/* Allgemeine Button-Stile */
button {
    background-color: #5CA8FF;
    color: white;
    padding: 10px 15px;
    font-size: 14px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 15px; 
}
</style>
