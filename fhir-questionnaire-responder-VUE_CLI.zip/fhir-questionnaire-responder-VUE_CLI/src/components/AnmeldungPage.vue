<template>
    <!-- Main container for the login section -->
    <div class="login-container">
        <!-- Login area displayed when not logged in, not in registration, and profile is not visible -->
        <div v-if="!loggedIn && !showRegistration && !profileVisible" class="login-box">
            <!-- Logo and welcome message -->
            <div class="align-left">
                <img src="@/assets/questionnaire.png" alt="Questionnaire Logo" class="logo" style="max-height: 60px; width: auto;">
                <h2 style="color: #3581E5;">Willkommen zum Fragebogen-Editor</h2>
            </div>
            <!-- Login form -->
            <form @submit.prevent="login">
                <!-- Input fields for username and password -->
                <div class="input-group">
                    <label for="username" style="color: #000000; text-align: left;">Deine E-Mail-Adresse:</label>
                    <input type="text" v-model="username" id="username" required="" autocomplete="off">
                </div>
                <div class="input-group">
                    <label for="password" style="color: #000000; text-align: left;">Dein Passwort:</label>
                    <!-- Password input field with show/hide button -->
                    <div class="password-input-group">
                        <input type="password" v-model="password" id="password" required>
                        <button @mousedown="showPassword" @mouseup="hidePassword" @mouseleave="hidePassword" type="button" class="eye-button">
                            <img v-if="passwordVisible" src="https://img.icons8.com/material-sharp/24/000000/visible.png" alt="Anzeigen" />
                            <img v-else src="https://img.icons8.com/material-sharp/24/000000/invisible.png" alt="Verstecken" />
                        </button>
                    </div>
                    <!-- "Forgot password" link -->
                    <div class="align-left" style="margin-bottom: 20px;">
                        <router-link to="/forgot-password" style="color: #3581E5; cursor: pointer; text-decoration: none;">
                            Passwort vergessen?
                        </router-link>
                    </div>
                </div>
                <!-- Login button -->
                <button type="submit" style="background-color: #3581E5; text-align: left; margin-left: 0; margin-right: auto; display: block;">Anmelden</button>
            </form>

            <!-- Registration link and skip login button -->
            <div class="align-center">
                <div v-if="!showRegistration" style="margin-top: 20px;">
                    <!-- router-link to navigate to the registration page -->
                    <router-link to="/register" style="color: #3581E5; cursor: pointer; text-decoration: none;">
                        Noch keinen Account? Hier registrieren.
                    </router-link>
                </div>
                <div style="margin-top: 20px;">
                    <button @click="skipLoginAndNavigateToHome" style="background-color: #3581E5;">Anmeldung überspringen</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    data() {
        return {
            // User data for login
            username: '',
            password: '',
            // Indicates whether the password is visible
            passwordVisible: false,
            // Indicates whether the user is logged in
            loggedIn: false,
            // Indicates whether the registration page should be shown
            showRegistration: false,
            // Indicates whether the user profile is visible
            profileVisible: false,
        };
    },
    methods: {
        // Method to log in the user
        login() {
            // Data object for login
            const loginData = {
                email: this.username,
                password: this.password,
            };

            // Send request to the server's login endpoint
            axios.post('http://10.197.245.209:50000/login', loginData)
                .then(() => {
                    // Successful login
                    this.loggedIn = true;
                    alert('Anmeldung erfolgreich');
                })
                .catch(error => {
                    // Login error
                    console.error('Anmeldung fehlgeschlagen:', error);

                    if (error.response) {
                        // Server returned an error status code
                        alert(`Fehler bei der Anmeldung: ${error.response.data.message}`);
                    } else if (error.request) {
                        // Request was made, but no response received
                        alert('Keine Antwort vom Server erhalten. Überprüfe deine Internetverbindung.');
                    } else {
                        // Something went wrong during request preparation
                        alert('Ein Fehler ist aufgetreten. Überprüfe die Konsole für Details.');
                    }
                });
        },
        // Method to show the password
        showPassword() {
            this.passwordVisible = true;
            document.getElementById('password').type = 'text';
        },
        // Method to hide the password
        hidePassword() {
            this.passwordVisible = false;
            document.getElementById('password').type = 'password';
        },
        // Method to skip login and navigate to the home page
        skipLoginAndNavigateToHome() {
            this.$router.push('/home');
        },
    },
};
</script>

<style scoped>
  /* Styling for the entire body of the application */
  body {
    background-color: #f4f4f4;
  }

  /* Styles for left-aligned text */
  .align-left {
    text-align: left;
  }

  /* Styles for center-aligned text */
  .align-center {
    text-align: center;
  }

  /* Styles for the login area */
  .login-box {
    max-width: 450px;
    margin: 0 auto;
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  /* Styles for labels within the login area */
  .login-box label {
    display: block;
    width: 100%;
    margin-bottom: 10px;
  }

  /* Styles for input fields within the login area */
  .login-box input {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  /* Styles for the password input field and show/hide button */
  .password-input-group {
    position: relative;
  }

  .eye-button {
    cursor: pointer;
    background: none;
    border: none;
    position: absolute;
    right: 0px;
    top: 55%;
    transform: translateY(-50%);
  }

  /* Styles for the logo within the login area */
  .logo {
    max-height: 60px;
    width: auto;
  }

  /* Styles for the heading within the login area */
  h2 {
    color: #3581E5;
  }

  /* Styles for general buttons */
  button {
    padding: 10px 16px;
    font-size: 18px;
    line-height: 1.3333333;
    border-radius: 6px;
  }
</style>
