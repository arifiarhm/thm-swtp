// Importing the `createStore` function from Vuex
import { createStore } from 'vuex';

// Creating and exporting the Vuex store
export default createStore({
  // State represents the data of the application
  state: {
    // Initial state for the access token, set to `null`
    accessToken: null,
  },
  // Mutations are synchronous functions that modify the state
  mutations: {
    // Mutation to set the access token in the state
    setAccessToken(state, accessToken) {
      state.accessToken = accessToken;
    },
    // Mutation to clear or reset the access token in the state
    clearAccessToken(state) {
      state.accessToken = null;
    },
  },
});
