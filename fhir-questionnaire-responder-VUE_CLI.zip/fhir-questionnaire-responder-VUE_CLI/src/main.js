import { createApp } from 'vue';
import App from './App.vue';
import { createRouter, createWebHistory } from 'vue-router';
import axios from 'axios';

// Importiere Komponenten
import AnmeldungPage from './components/AnmeldungPage.vue';
import RegistrierenPage from './components/RegistrierenPage.vue';
import HomePage from './views/HomePage.vue';
import QuestionnairePage from './components/QuestionnairePage.vue';
import ForgotPasswordPage from './components/ForgotPasswordPage.vue';
import ResetPasswordPage from './components/ResetPasswordPage.vue';
import EditQuestionnairePage from './components/EditQuestionnairePage.vue';
import ProfilePage from './components/ProfilePage.vue';

import '@fortawesome/fontawesome-free/css/all.css';

const app = createApp(App);
app.config.globalProperties.$axios = axios;

// Setze die withCredentials-Option für alle Axios-Anfragen
axios.defaults.withCredentials = true;

// erstellte App-Instanz und bindet sie an den #app-Element
const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', redirect: '/login' },
    { path: '/login', component: AnmeldungPage },
    { path: '/register', component: RegistrierenPage },
    { path: '/home', component: HomePage },
    { path: '/questionnaires', component: QuestionnairePage },
    { path: '/forgot-password', component: ForgotPasswordPage},
    { path: '/reset-password', component: ResetPasswordPage},
    { path: '/editor', component: EditQuestionnairePage },
    { path: '/profile', component: ProfilePage },
  ],
});

app.use(router);

app.mount('#app');
