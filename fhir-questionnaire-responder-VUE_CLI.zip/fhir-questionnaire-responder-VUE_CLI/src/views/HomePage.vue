<template>
  <div>
    <!-- Navigationsleiste -->
    <nav class="menu" :class="{ 'menu-visible': menuVisible }">
      <div class="shadow-3 navbar-content">
        <div class="menu-links">
          <!-- Home-Link -->
          <a href="#" class="menu-link">Home</a>
          <!-- Link für den Fragebogen-Editor -->
          <router-link to="/editor" class="menu-link">Fragebogen-Editor</router-link>
          <!-- Link für die Fragebogenverwaltung -->
          <router-link to="/questionnaires" class="menu-link">Fragebogenverwaltung</router-link>
          <!-- Profil-Link -->
          <a href="#" class="menu-link">Profil</a>
        </div>
      </div>
    </nav>

    <!-- Header-Bereich -->
    <header>
      <!-- Questionnaire-Logo mit Klickfunktionalität zum Schließen des Menüs -->
      <img src="@/assets/questionnaire.png" alt="Questionnaire Logo" class="logo-in-menu" @click="closeMenu">
    </header>

    <!-- Overlay for the menu -->
    <div class="menu-overlay" @click="menuVisible = false" v-show="menuVisible"></div>

    <!-- Hauptinhalt -->
    <main>
      <router-view></router-view>
      <div id="home">
        <!-- Hier kommt der Inhalt, der nach dem Klick auf Home angezeigt werden soll -->
        <h2>Home</h2>
        <p>Herzlich Willkommen zum FHIR-Questionnaire-Responder</p>
      </div>
    </main>

    <!-- Footer-Bereich -->
    <footer>
      <!-- Copyright-Information -->
      <p>© 2024 FHIR Questionnaire Responder Projekt | Gruppe 3 | Technische Hochschule Mittelhessen (THM)</p>
    </footer>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // Zustand des Menüs
      menuVisible: false,
    };
  },
  methods: {
    // Methode zum Umschalten des Menüs
    toggleMenu() {
      this.menuVisible = !this.menuVisible;
    },
    // Methode zum Schließen des Menüs
    closeMenu() {
      this.menuVisible = false;
    },
  },
};
</script>

<style>
/* Gemeinsame Stile für den gesamten Body der Anwendung */
body {
  font-family: 'Open Sans Condensed', sans-serif;
  font-size: 16px;
  margin: 0;
  padding: 0;
  background-color: white;
  overflow-x: hidden;
}

/* Stile für den Header-Bereich */
header {
  background-color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0;
  margin: 0;
  border-bottom: 1px solid #ccc;
}

/* Stile für das Questionnaire-Logo im Menü mit Klickfunktionalität */
.logo-in-menu {
  max-height: 70px;
  width: auto;
  margin: 5px auto;
}

/* Stile für Menü-Links */
.menu-link {
  color: white;
  text-decoration: none;
  font-size: 16px;
  margin-left: 20px;
  position: relative;
  display: flex;
  align-items: center; /* Hinzugefügt, um die Ausrichtung zu korrigieren */
}

/* Stile für Hover-Effekt auf Menü-Links */
.menu-link:hover {
  background-color: transparent !important;
  color: white;
}

/* Stile für das Menü */
.menu {
  display: flex;
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  background-color: #3581E5;
  padding: 6px;
  z-index: 2;
}

/* Stile für den Inhalt der Navigationsleiste */
.navbar-content {
  width: 100%;
  display: flex;
  justify-content: space-between;
  margin: 0;
  padding: 0;
}

/* Stile für Menü-Links */
.menu a {
  color: black;
  text-decoration: none;
  font-size: 17px;
}

/* Stile für Hover-Effekt auf Menü-Links */
.menu a:hover {
  background-color: #ddd;
  color: white;
}

/* Stile für sichtbares Menü */
.menu-visible {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

/* Stile für Menü-Links */
.menu-links {
  display: flex;
  justify-content: flex-end;
}

/* Stile für den Hauptinhalt */
main {
  padding: 20px;
  background-color: white;
}

/* Stile für den Footer-Bereich */
footer {
  background-color: #eee;
  color: black;
  text-align: center;
  padding: 1em;
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
}
</style>
